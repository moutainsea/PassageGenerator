# PassageGenerator 网文生成器

基于 autonomous workflow 的网络小说生成器。依据本项目 `architechture.txt` 架构与 `PassageGenerator_rules.mdc` 规则实现。

## 功能

### 一、调研当前最热的网文小说
- 按当前时间查询最热 **top 20** 小说（名称/简介/分类/章节名称/详细大纲），存为 `{时间戳}_hot20.json`
- 按小说**类别标签**查询最热 **top 2** 小说（大纲为超详细），存为 `{时间戳}_{标签}.json`

### 二、根据信息生成小说
- 小说结构：名称(≤10字)、简介(≤100字)、分类、大纲、章节内容
- **大纲以事件线为主**：大事件 → 中事件 → 小事件
  - 小事件 = 事件影响 + 事件背景 + 主角人数(≥1) + 配角人数(0-3) + 人物形象 + 人物行为 + 所处时间 + 所在地表状态表
  - 小事件的转移 = 状态表的转移
- 独立事件库文件；并派生维护：
  - 主角人物形象库、配角人物形象库（可复用，场景如 故地重逢/碰巧遇到/共同目标）
  - 地点库、时间库（可复用）
- **章节内容**：每个章节扩写一个小事件；书写时结合前 1 章与后 1 章的标题/大纲/内容；每章 2200-3200 字

### 三、检查小说内容、大纲、章节名称
- 章节内容/大纲/章节名称与小说总体大纲对应节点是否匹配
- 人物/时间/地点与各库对应节点是否匹配、合理
- 章节内容与章节名称是否重复（n-gram 相似度）
- 反思：错漏/不通顺/太AI风格（结合前后章节），并支持自动修正

### 四、自动化发布流程
- 暂缓（架构标注）。

## 目录结构

```
PassageGenerator/
├── architechture.txt            # 架构说明（最高参考）
├── requirements.txt             # 实际零依赖（说明用）
├── config.py                    # 全局配置（路径/LLM/.env加载/生成规则）
├── main.py                      # CLI 入口（research/generate/history/status）
├── .env                         # 本地密钥配置（gitignore，勿提交）
├── .gitignore
├── models/                      # 数据模型
│   ├── character.py             # 人物（主角/配角）
│   ├── event.py                 # 事件线（大/中/小事件+状态表）
│   ├── location.py              # 地点库
│   ├── timeline.py              # 时间库
│   └── novel.py                 # 小说/章节/大纲
├── storage/                     # 库管理与持久化
│   ├── libraries.py             # 主角/配角/地点/时间库（JSON）
│   └── research_store.py        # 调研结果存储
├── core/                        # 核心生成逻辑
│   ├── llm_client.py            # LLM 客户端（多平台故障转移+mock）
│   ├── researcher.py            # 调研模块
│   ├── outline_builder.py       # 大纲构建（事件线+回填各库+标题清洗）
│   ├── chapter_writer.py        # 章节写作（结合前后章节）
│   ├── checker.py               # 检查与反思
│   └── generator.py             # 生成器主流程
└── output/                      # 运行时生成（gitignore）
    ├── research/                # 调研 json
    ├── novels/                  # 生成的小说（json + txt）
    └── libraries/               # 各库 json
```

## 安装

本项目使用 Python 标准库（`urllib`/`json`/`argparse` 等）调用 LLM，**零第三方依赖**，兼容 Python 3.5+，无需 `pip install`。

## 配置 LLM

采用 OpenAI 兼容接口，支持**多平台故障转移**：GLM（首选）→ Kimi（第二）→ DeepSeek（第三）→ mock（兜底）。某平台调用失败自动切换下一家，全部失败才回退 mock。

### 方式一：`.env` 文件（推荐，key 不进代码库）

项目根目录已内置 `.env`（已被 `.gitignore` 忽略），填入任一平台 Key 即可：

```ini
# DeepSeek
DEEPSEEK_API_KEY=sk-xxxx
DEEPSEEK_MODEL=deepseek-chat
DEEPSEEK_BASE_URL=https://api.deepseek.com/v1

# 智谱 GLM（首选，如需启用）
# GLM_API_KEY=...
# GLM_MODEL=glm-4-plus

# 月之暗面 Kimi（第二顺位，如需启用）
# KIMI_API_KEY=...
# KIMI_MODEL=moonshot-v1-32k
```

### 方式二：环境变量（PowerShell）

```powershell
$env:DEEPSEEK_API_KEY="sk-xxxx"   # 或 GLM_API_KEY / KIMI_API_KEY
```

### 查看当前启用状态

```bash
python main.py status
```

### 强制 mock 模式（无需 Key，输出占位内容用于联调）

```bash
# PowerShell
$env:LLM_MOCK="1"
```

## 使用

```bash
# 1. 调研当前最热 top20
python main.py research

# 2. 按标签调研 top2
python main.py research --tag 玄幻

# 3. 生成小说（mock 模式可直接运行）
python main.py generate --category 玄幻 --tags 玄幻,升级 --chapters 5

# 4. 带标签调研后生成
python main.py generate --category 玄幻 --tags 玄幻,升级 --chapters 8 --research-tag 玄幻

# 5. 查看历史调研文件
python main.py history
```

## 生成规则说明

- 最高级规则：反思检查、结合前后章节（前1后1）校验
- 次高级规则：网文格式、事件+人物+时间+地点、不与参考雷同、每章 2200-3200 字
- 普通规则：语义通顺、词语恰当、段落合理、章节完整

## 输出

- `output/novels/{小说名}.json`：完整结构化数据（含事件线大纲与各库引用）
- `output/novels/{小说名}.txt`：可读正文
- `output/research/*.json`：调研结果
- `output/libraries/*.json`：主角/配角/地点/时间库（跨小说复用）
