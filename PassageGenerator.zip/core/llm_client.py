# -*- coding: utf-8 -*-
"""LLM 客户端：多平台故障转移（GLM > Kimi > DeepSeek）+ mock 兜底。

实现说明：
  - 使用 Python 标准库 urllib 直接调用 OpenAI 兼容 /chat/completions 接口，
    零第三方依赖，兼容 Python 3.5+。
  - 按 config.LLM_PROVIDERS 优先级依次尝试；某平台失败自动切换下一个；
    上次成功的平台会被缓存、后续优先使用；全部失败回退 mock。
"""
import json
import re

from config import (
    LLM_PROVIDERS, LLM_TEMPERATURE, LLM_MAX_TOKENS, LLM_TIMEOUT, LLM_MOCK,
)


class LLMClient(object):
    """统一 LLM 调用封装（多平台故障转移，OpenAI 兼容）。"""

    def __init__(self, providers=None, temperature=None, max_tokens=None,
                 timeout=None, mock=None):
        self.providers = providers if providers is not None else list(LLM_PROVIDERS)
        self.temperature = temperature if temperature is not None else LLM_TEMPERATURE
        self.max_tokens = max_tokens if max_tokens is not None else LLM_MAX_TOKENS
        self.timeout = timeout if timeout is not None else LLM_TIMEOUT
        # 有 Key 的平台（按配置优先级）
        self._available = [p for p in self.providers if p.get("api_key")]
        self._preferred = None          # 上次成功平台的索引（缓存）
        self.mock = mock if mock is not None else LLM_MOCK
        # 无任何可用平台时强制 mock
        if not self.mock and not self._available:
            self.mock = True

    # ---------------- 基础对话 ----------------
    def chat(self, system_prompt, user_prompt):
        """普通文本对话，自动故障转移。"""
        if self.mock or not self._available:
            return self._mock_text(system_prompt, user_prompt)
        # 调用顺序：上次成功的优先，其余按配置优先级
        order = list(range(len(self._available)))
        if self._preferred is not None and self._preferred in order:
            order.remove(self._preferred)
            order.insert(0, self._preferred)
        last_err = None
        for i in order:
            p = self._available[i]
            try:
                result = self._http_chat(p, system_prompt, user_prompt)
                if result:
                    if self._preferred != i:
                        print("[LLM] 使用平台: " + p["name"] + " (" + p["model"] + ")")
                    self._preferred = i
                    return result
            except Exception as e:  # pragma: no cover
                last_err = e
                print("[LLM] " + p["name"] + " 调用失败，切换下一平台: " + str(e))
        print("[LLM] 所有平台均不可用，回退 mock 模式。最后错误: " + str(last_err))
        return self._mock_text(system_prompt, user_prompt)

    def _http_chat(self, provider, system_prompt, user_prompt):
        """用 urllib 调用指定平台的 OpenAI 兼容接口，失败自动重试。"""
        import urllib.request, urllib.error, time
        base_url = provider["base_url"].rstrip("/")
        url = base_url + "/chat/completions"
        payload = {
            "model": provider["model"],
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers = {
            "Content-Type": "application/json; charset=utf-8",
            "Authorization": "Bearer " + provider["api_key"],
        }
        last_err = None
        for attempt in range(3):
            try:
                req = urllib.request.Request(url, data=data, headers=headers, method="POST")
                resp = urllib.request.urlopen(req, timeout=self.timeout)
                body = resp.read().decode("utf-8")
                obj = json.loads(body)
                choices = obj.get("choices") or []
                if choices:
                    return choices[0].get("message", {}).get("content", "") or ""
                if obj.get("error"):
                    raise RuntimeError(str(obj["error"]))
                return ""
            except (urllib.error.URLError, urllib.error.HTTPError, OSError, IOError) as e:
                last_err = e
                if attempt < 2:
                    time.sleep(3)
        raise last_err or RuntimeError("HTTP request failed")

    # ---------------- JSON 输出 ----------------
    def chat_json(self, system_prompt, user_prompt):
        """要求模型返回 JSON，自动解析（兼容 ```json 包裹）。"""
        text = self.chat(system_prompt, user_prompt)
        return self._parse_json(text)

    @staticmethod
    def _parse_json(text):
        text = text.strip()
        m = re.search(r"```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```", text, re.S)
        if m:
            text = m.group(1)
        else:
            s = text.find("{")
            e = text.rfind("}")
            if s != -1 and e != -1 and e > s:
                text = text[s:e + 1]
        try:
            return json.loads(text)
        except Exception:
            return {"_raw": text}

    # ---------------- 状态查询 ----------------
    def status(self):
        """返回当前可用的平台列表与 mock 状态，便于调试。"""
        return {
            "mock": self.mock,
            "available": [p["name"] for p in self._available],
            "preferred": self._available[self._preferred]["name"] if self._preferred is not None else None,
        }

    # ---------------- mock 实现 ----------------
    @staticmethod
    def _mock_text(system_prompt, user_prompt):
        """mock 文本：返回结构化占位，便于上层解析测试。

        用全文(user_prompt)判断、按优先级匹配，避免章节请求被误判为大纲。
        """
        full = user_prompt

        # 1. 调研最热小说
        if "调研" in full or "热度" in full or "hot" in full.lower():
            return json.dumps({
                "items": [
                    {
                        "name": "示例小说·占位",
                        "brief": "这是一部用于流程联调的示例小说简介。",
                        "category": "玄幻",
                        "tags": ["玄幻", "升级"],
                        "chapter_names": ["第一章 启程", "第二章 异变"],
                        "outline": "示例大纲：主角觉醒天赋，踏上修行之路……",
                        "heat": 9900,
                        "source": "mock",
                    }
                ]
            }, ensure_ascii=False)

        # 2. 检查/反思（须在章节之前，因检查 prompt 含"正文摘要"）
        if "反思" in full:
            return json.dumps({"pass": True, "issues": [], "advice": "mock 通过"}, ensure_ascii=False)

        # 3. 章节正文（须在"事件线"之前，因章节 prompt 含"事件详情"）
        if ("请直接输出" in full and "正文" in full) or "扩写" in full or "字数 2200" in full:
            import re as _re
            mt = _re.search(r"第(\d+)章《([^》]*)》", full)
            idx = int(mt.group(1)) if mt else 1
            ctitle = mt.group(2) if mt else "觉醒"
            leads = [
                "夜风裹挟着焦土的气味掠过青石村的断壁残垣。",
                "晨光穿透薄雾，洒在蜿蜒的山道之上。",
                "宗门的钟声悠悠回荡，惊起檐角栖息的飞鸟。",
                "密林深处传来低沉的兽吼，令人心头发紧。",
                "烈日当空，演武场上尘土飞扬。",
            ]
            lead = leads[(idx - 1) % len(leads)]
            paras = []
            for k in range(40):
                # 每段嵌入唯一标识（章号+段号），确保章间 n-gram 不重复
                para = lead + "少年攥紧了手中残破的木棍，指节因用力而泛白。"
                suffix = "（占位·第" + str(idx) + "章《" + ctitle + "》·段" + str(k + 1) + "，流程联调用，实际由大模型生成。）"
                paras.append(para + suffix)
            return "\n\n".join(paras)

        # 4. 小说基本信息（名称/简介）
        if '"name"' in full and '"brief"' in full:
            return json.dumps({
                "name": "觉醒之夜",
                "brief": "村落少年在浩劫中觉醒隐藏血脉，自此踏上修行之路，于乱世中求存求强。",
                "category": "玄幻",
            }, ensure_ascii=False)

        # 5. 大纲事件线（按请求章节数动态生成小事件）
        if "事件线" in full or "大事件" in full:
            import re as _re
            m = _re.search(r"章节数[：:]\s*(\d+)", full)
            n = int(m.group(1)) if m else 1
            titles = ["觉醒", "离乡", "入宗", "试炼", "突破", "历险",
                      "对决", "真相", "抉择", "蜕变"]
            small_events = []
            for i in range(1, n + 1):
                t = titles[i - 1] if i <= len(titles) else ("第" + str(i) + "幕")
                small_events.append({
                    "id": "B1M1S" + str(i),
                    "title": "第" + str(i) + "章 " + t,
                    "impact": "主角迎来第" + str(i) + "次转折",
                    "background": "事件" + str(i) + "的背景铺垫",
                    "protagonist_count": 1,
                    "supporting_count": 1 if i % 2 == 0 else 0,
                    "character_ids": ["male_lead"] + (["villain_1"] if i % 2 == 0 else []),
                    "character_image": "少年坚毅，眼神倔强",
                    "behavior": "主角在事件" + str(i) + "中的关键行为",
                    "time_desc": "初春·第" + str(i) + "日",
                    "location_desc": "青石村·场景" + str(i),
                    "state": {
                        "time_id": "T" + str(i),
                        "location_id": "L" + str(i),
                        "protagonist_ids": ["male_lead"],
                        "supporting_ids": ["villain_1"] if i % 2 == 0 else [],
                        "character_states": {"male_lead": "状态" + str(i)},
                        "location_status": "场景" + str(i) + "状态",
                    },
                    "outline": "第" + str(i) + "章大纲：主角经历" + t + "，推动剧情发展。",
                    "chapter_index": i,
                })
            return json.dumps({
                "big_events": [{
                    "id": "B1", "title": "觉醒与成长",
                    "summary": "主角觉醒天赋，一路成长。",
                    "middle_events": [{
                        "id": "B1M1", "title": "主线",
                        "summary": "主角的成长历程。",
                        "small_events": small_events,
                    }],
                }]
            }, ensure_ascii=False)

        return "【mock 占位回复】" + user_prompt[:80]


# 默认单例
_default_client = None


def get_llm():
    global _default_client
    if _default_client is None:
        _default_client = LLMClient()
    return _default_client
