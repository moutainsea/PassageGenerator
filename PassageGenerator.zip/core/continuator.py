# -*- coding: utf-8 -*-
"""续写模块：加载已有小说 + 调研文件，生成后续 N 章并追加到 json 和 txt。

功能：
  1. 读取 novels 目录下的小说 json 文件
  2. 读取 research 目录下的调研 json 文件作为参考上下文
  3. 基于最后章节的状态表，生成 N 个新小事件（大纲扩展）
  4. 为新小事件逐章写作正文
  5. 追加到原 json（保留前文不变）和 txt 文件
"""
import json
import re
from pathlib import Path

from config import NOVEL_DIR, RESEARCH_DIR, LIBRARY_DIR, DEFAULT_PLATFORM, NOVEL_PLATFORMS
from core.llm_client import LLMClient, get_llm
from core.outline_builder import OutlineBuilder
from core.chapter_writer import ChapterWriter
from core.checker import NovelChecker
from core.character_consistency import CharacterConsistencyChecker
from models.novel import Novel, Chapter, NovelOutline, Subplot
from models.event import SmallEvent, EventState, MiddleEvent, BigEvent, EventLibrary
from storage.libraries import Libraries, library_manager, get_libraries
from core.emotion_curve import EmotionCurveGenerator


class NovelContinuator(object):
    """小说续写器。

    platform 决定加载哪套独立库与小说文件，续写追加到对应平台产物。
    """

    def __init__(self, llm=None, libs=None, platform=DEFAULT_PLATFORM):
        self.llm = llm or get_llm()
        self.platform = platform if platform in NOVEL_PLATFORMS else DEFAULT_PLATFORM
        self.libs = libs or get_libraries(self.platform)
        self.builder = OutlineBuilder(self.llm, self.libs)
        self.writer = ChapterWriter(self.llm, self.libs, self.builder)
        self.checker = NovelChecker(self.llm, self.libs, self.builder)
        self.consistency_checker = CharacterConsistencyChecker(self.llm, self.libs)

    # ---------------- 加载 ----------------
    def load_novel(self, novel_name):
        """从 novels 目录加载小说。

        按平台前缀查找：优先 {platform}_{name}.json，起点向后兼容无前缀 {name}.json。
        novel_name 可带或不带平台前缀。
        """
        safe = "".join(ch if (ch.isalnum() or ch in "_-") else "_" for ch in novel_name)
        prefix = (self.platform + "_") if self.platform != DEFAULT_PLATFORM else ""
        # 候选路径：带前缀 / 不带前缀（起点兼容）/ 直接用传入名
        candidates = []
        if prefix:
            candidates.append(NOVEL_DIR / (prefix + safe + ".json"))
        candidates.append(NOVEL_DIR / (safe + ".json"))
        # 若传入名本身已带平台前缀，也直接尝试
        if prefix and (safe + ".json") not in [c.name for c in candidates]:
            candidates.append(NOVEL_DIR / (safe + ".json"))
        path = None
        for c in candidates:
            if c.exists():
                path = c
                break
        if path is None:
            raise FileNotFoundError("小说文件不存在（平台=" + self.platform + "）: " + str(candidates))
        data = json.loads(path.read_text(encoding="utf-8"))
        return Novel.from_dict(data), path

    def load_references(self):
        """从 research 目录 + 各库 汇总参考文本（优先本平台调研）。"""
        parts = []
        # 优先加载本平台调研产物
        platform_marker = self.platform + "_hot"
        platform_files = [p for p in sorted(RESEARCH_DIR.glob("*.json"))
                          if platform_marker in p.stem]
        other_files = [p for p in sorted(RESEARCH_DIR.glob("*.json"))
                       if platform_marker not in p.stem]
        # 本平台调研优先，其他调研作补充
        for p in platform_files + other_files[:3]:
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                items = data.get("items", [])
                for it in items:
                    parts.append(
                        "《" + str(it.get("name", "")) + "》｜"
                        "来源:" + str(it.get("source", "")) + "｜"
                        "分类:" + str(it.get("category", "")) + "｜"
                        "简介:" + str(it.get("brief", "")) + "\n"
                        "大纲:" + str(it.get("outline", ""))[:600]
                    )
            except Exception:
                pass
        # 追加各库摘要
        parts.append(self._libraries_summary())
        return "\n---\n".join(parts)

    def _libraries_summary(self):
        """生成人物库/地点库/时间库摘要文本，供续写上下文使用。"""
        lines = ["=== 人物库 ==="]
        for c in self.libs.characters.all_characters():
            lines.append(
                c.name + "(" + c.role_label + ") 性格:" + c.personality
                + " 技能:" + str(c.skills)[:100] + " 道具:" + str(c.items)[:100]
                + " 称号:" + str(c.titles)[:60] + " 背景:" + c.background[:80]
            )
        lines.append("=== 地点库 ===")
        for loc in list(self.libs.locations.locations.values())[:10]:
            lines.append(loc.name + "(" + loc.type + ") " + loc.description[:80])
        lines.append("=== 时间线 ===")
        for tp in sorted(self.libs.timeline.points.values(),
                         key=lambda x: x.order)[:15]:
            lines.append(tp.name + " " + tp.description[:60])
        return "\n".join(lines)

    # ---------------- 续写 ----------------
    def continue_novel(self, novel_name, n_chapters):
        """续写 N 章并保存。
        
        返回 (novel, report)。
        """
        novel, path = self.load_novel(novel_name)
        reference = self.load_references()
        existing_count = len(novel.chapters)
        print("[续写] 已加载《" + novel.name + "》，现有 " + str(existing_count) + " 章")
        print("[续写] 参考信息: " + str(len(reference)) + " 字符（含调研+各库）")

        # 0.5 分析已有章节情绪曲线（供续写参考）
        emotion_ref = ""
        try:
            emo_gen = EmotionCurveGenerator(self.llm)
            emo_curve = emo_gen.analyze_novel(novel)
            emotion_ref = emo_gen.build_curve_prompt(emo_curve)
            if emotion_ref:
                print("[续写] 情绪曲线参考已生成，" + str(len(emotion_ref)) + " 字符")
                reference = reference + "\n\n" + emotion_ref
        except Exception as e:
            print("[续写] 情绪曲线分析跳过: " + str(e))
        
        # 计算 ID 顺延：找到最后一个 S 序号
        self._next_s_id = self._get_max_s_number(novel) + 1
        
        # 1. 扩展大纲
        new_start = existing_count + 1
        new_end = existing_count + n_chapters
        print("[续写] 生成大纲: 第 " + str(new_start) + " ~ " + str(new_end) + " 章 (ID 从 S" + str(self._next_s_id) + " 起)...")
        new_event_lib = self._generate_extended_outline(
            novel, n_chapters, new_start, reference
        )
        
        # 1.5 新增角色冲突预扫描（认知污染/大纲污染/角色不一致检测）
        self._scan_new_character_conflicts(new_event_lib, novel)
        
        # 2. 回填各库 + 清洗标题 + 更新 chapter_event_map
        self.builder.character_conflicts = []
        for b, m, s in new_event_lib.iter_small_events():
            self.builder._sync_to_libraries(b, m, s)
            if s.chapter_index is None:
                s.chapter_index = len(novel.outline.chapter_event_map) + 1
            s.title = self.builder._clean_chapter_title(s.title, s.chapter_index)
            novel.outline.chapter_event_map[s.chapter_index] = s.id
        
        # 合并事件线
        if new_event_lib.big_events:
            novel.outline.event_library.big_events.extend(new_event_lib.big_events)
        self.libs.save()
        
        # 1.8 扩展分线结构：为续写章节生成分线归属
        self._extend_subplots(novel, n_chapters, new_start, new_end)
        
        # 3. 续写章节正文
        print("[续写] 生成 " + str(n_chapters) + " 章正文...")
        prev_chapters = list(novel.chapters)
        for idx in range(new_start, new_end + 1):
            s = self.builder.get_small_event_by_chapter(novel.outline, idx)
            if s is None:
                print("[续写] 警告: 第 " + str(idx) + " 章无对应小事件，跳过")
                continue
            ch = self.writer.write_chapter(
                novel.outline, idx, prev_chapters, reference
            )
            novel.chapters.append(ch)
            prev_chapters.append(ch)
            print("  第" + str(idx) + "章《" + ch.title + "》 "
                  + str(len("".join(ch.content.split()))) + "字")
        
        # 4. 检查
        print("[续写] 检查...")
        self.checker._novel_path = path
        report = self.checker.check(novel)
        print("  通过=" + str(report.passed) + " 问题数=" + str(len(report.issues)))
        for iss in report.issues[:10]:
            print("    - " + iss)
        if not report.passed:
            for iss in report.issues:
                import re
                m = re.search(r"第(\d+)章字数不足", iss)
                if m:
                    ci = int(m.group(1))
                    for ch in novel.chapters:
                        if ch.index == ci:
                            try:
                                fixed = self.checker.suggest_fix(ch, iss)
                                if fixed and len("".join(fixed.split())) > 100:
                                    ch.content = fixed
                            except Exception:
                                pass
            # 修复后重新检查
            self.checker._novel_path = path
            report = self.checker.check(novel)
        
        # 5. 保存（含检查修复后的最终版）
        self.libs.save()
        self._save_novel(novel, path)
        return novel, report

    def _scan_new_character_conflicts(self, new_event_lib, novel):
        """扫描新大纲中的新增角色，检测与已有角色的行为冲突。

        防止续写时新角色与旧角色干了同一件事（认知污染/大纲污染/角色不一致）。
        扫描 character_library.json 已有角色，与新角色对比 behavior/定位。
        """
        new_small_events = [s for _, _, s in new_event_lib.iter_small_events()]
        if not new_small_events:
            return
        print("[续写] 扫描新增角色一致性（检测认知污染/大纲污染）...")
        try:
            report = self.consistency_checker.scan_new_characters(
                new_small_events, novel
            )
        except Exception as e:  # pragma: no cover
            print("[续写] 角色一致性扫描异常: " + str(e))
            return
        if report.passed:
            print("[续写] 新增角色一致性检查通过，未发现行为重复")
            return
        print("[续写] 发现 " + str(len(report.conflicts)) + " 处角色行为冲突：")
        for c in report.conflicts:
            print(
                "  - 新角色「" + str(c["new_name"]) + "」≈ 已有角色「"
                + str(c["existing_name"]) + "」 (相似度 "
                + str(round(c["similarity"], 2)) + ") "
                + str(c["reason"])
            )
            if c.get("suggestion"):
                print("    → 区分建议: " + str(c["suggestion"]))

    def _get_max_s_number(self, novel):
        """获取现有事件线中最大的 S 序号。"""
        max_s = 0
        for _, _, s in novel.outline.event_library.iter_small_events():
            m = re.search(r"S(\d+)$", s.id)
            if m:
                max_s = max(max_s, int(m.group(1)))
        return max_s

    def _generate_extended_outline(self, novel, n, start_idx, reference):
        """生成扩展的事件线大纲（从现有大纲最后一章状态继续）。

        章节较多时自动分批生成（每批≤15章），避免输出超max_tokens。"""
        import math
        BATCH = 15
        full_start = start_idx
        # 获取最后一章的状态表 + 前文摘要
        prev_summary = self._build_prev_summary(novel)
        last_state_desc = self._build_last_state(novel)

        if n <= BATCH:
            return self._generate_outline_batch(
                novel, prev_summary, last_state_desc, reference,
                start_idx, start_idx + n - 1
            )

        print("  [续写大纲] 分" + str(int(math.ceil(float(n) / BATCH))) + "批生成...")
        all_small = []
        for b in range(int(math.ceil(float(n) / BATCH))):
            s = full_start + b * BATCH
            e = min(full_start + (b + 1) * BATCH - 1, full_start + n - 1)
            print("  [续写大纲] 第" + str(b + 1) + "批: 第" + str(s) + "~" + str(e) + "章")
            lib = self._generate_outline_batch(
                novel, prev_summary, last_state_desc, reference, s, e
            )
            for bg, md, sm in lib.iter_small_events():
                sm.chapter_index = sm.chapter_index or (full_start + len(all_small))
                all_small.append(sm)
            # 更新上下文供下一批
            if all_small:
                last_sm = all_small[-1]
                last_state_desc = (
                    "上一批最后状态: 时间=" + str(last_sm.time_desc)
                    + " 地点=" + str(last_sm.location_desc)
                    + " 行为=" + str(last_sm.behavior)
                )
        from models.event import MiddleEvent, BigEvent
        big = BigEvent(id="B2", title="续写篇章", summary="主角的后续历程。",
                       middle_events=[MiddleEvent(id="B2M1", title="新篇章",
                        summary="承接前文剧情线。", small_events=all_small)])
        return EventLibrary(big_events=[big])

    def _build_prev_summary(self, novel):
        lines = []
        for ch in novel.chapters[-3:]:
            lines.append(
                "第" + str(ch.index) + "章《" + ch.title + "》大纲: " + ch.outline
                + "\n正文摘要: " + ch.content[:200]
            )
        return "\n\n".join(lines)

    def _build_last_state(self, novel):
        last_small = None
        for _, _, s in novel.outline.event_library.iter_small_events():
            if s.chapter_index == len(novel.chapters):
                last_small = s
                break
        if last_small:
            return (
                "最后状态: 时间=" + str(last_small.time_desc)
                + " 地点=" + str(last_small.location_desc)
                + " 行为=" + str(last_small.behavior)
                + " 影响=" + str(last_small.impact)
            )
        return ""

    def _generate_outline_batch(self, novel, prev_summary, last_state_desc,
                                 reference, start_idx, end_idx):
        """生成一段扩展大纲。"""
        n = end_idx - start_idx + 1
        # 构建已有分线摘要
        subplot_summary = self._build_subplot_summary(novel)
        system = (
            "你是顶级网文大纲架构师。你正在续写一部连载小说的后续章节大纲。"
            "你需要基于前面章节的剧情，延续事件线，确保情节衔接连贯。\n"
            "【分线叙事制——最高优先级】小说采用多分线交替叙事："
            "须延续已有分线结构，一个分线完成一个小阶段后切换到另一分线，"
            "避免读者疲惫。分线切换处须有自然衔接（时间推移/因果联系/人物心理），不得生硬跳转。"
            "每章标题须体现所属分线主题。返回 JSON。"
        )
        user = (
            "小说名称: 《" + novel.name + "》\n"
            "简介: " + novel.brief + "\n"
            "分类: " + novel.category + " 标签: " + str(novel.tags) + "\n"
            "续写范围: 第" + str(start_idx) + "~" + str(end_idx) + "章（共" + str(n) + "章）\n\n"
            "=== 已有分线结构 ===\n" + subplot_summary + "\n\n"
            "=== 前文 ===\n" + prev_summary + "\n\n"
            + last_state_desc + "\n\n"
            "=== 参考 ===\n" + reference[:1000] + "\n\n"
            "【分线要求】续写章节须延续上述分线交替规律，在 outline 字段开头标注 [分线名]。"
            "返回 JSON，chapter_index 从 " + str(start_idx) + " 到 " + str(end_idx)
            + " 连续递增。格式：\n"
            "{\"big_events\":[{\"id\":\"B2\",\"title\":\"续\",\"summary\":\"\","
            "\"middle_events\":[{\"id\":\"B2M1\",\"title\":\"\",\"summary\":\"\","
            "\"small_events\":[{\"id\":\"...\",\"title\":\"标题\",\"impact\":\"\","
            "\"background\":\"\",\"protagonist_count\":1,\"supporting_count\":0,"
            "\"character_ids\":[\"male_lead\"],\"character_image\":\"\",\"behavior\":\"\","
            "\"time_desc\":\"\",\"location_desc\":\"\","
            "\"state\":{\"time_id\":\"\",\"location_id\":\"\",\"protagonist_ids\":[\"male_lead\"],"
            "\"supporting_ids\":[],\"character_states\":{},\"location_status\":\"\"},"
            "\"outline\":\"\",\"chapter_index\":" + str(start_idx) + "}]}]}]}"
        )
        data = self.llm.chat_json(system, user)
        # Clean up the data: remove unexpected fields from middle_events
        # and correct chapter_index values
        if "big_events" in data:
            chapter_offset = start_idx  # Expected starting chapter index
            for big_event in data.get("big_events", []):
                if "middle_events" in big_event:
                    for middle_event in big_event.get("middle_events", []):
                        # Remove unexpected fields from middle_event
                        middle_event.pop("background", None)
                        # Correct chapter_index in small_events
                        if "small_events" in middle_event:
                            for i, small_event in enumerate(middle_event.get("small_events", [])):
                                # Ensure chapter_index starts from start_idx and increments
                                if "chapter_index" in small_event:
                                    # If chapter_index is wrong, correct it
                                    expected_index = chapter_offset + i
                                    if small_event["chapter_index"] != expected_index:
                                        small_event["chapter_index"] = expected_index
        return EventLibrary.from_dict({"big_events": data.get("big_events", [])})

    def _build_subplot_summary(self, novel):
        """构建已有分线结构的摘要文本。"""
        if not novel.outline.subplots:
            return "（暂无分线结构，请设计2条分线）"
        lines = []
        for sp in novel.outline.subplots:
            sp_dict = sp.to_dict() if hasattr(sp, "to_dict") else sp
            lines.append(
                "- " + sp_dict.get("name", "") + "（" + sp_dict.get("id", "") + "）: "
                + sp_dict.get("description", "")[:100]
                + " | 已含章节: " + str(sp_dict.get("chapter_indices", []))
            )
        return "\n".join(lines)

    def _extend_subplots(self, novel, n_chapters, new_start, new_end):
        """为续写章节扩展分线归属。

        根据已有分线交替规律，将新章节分配到对应分线，
        并更新各分线的 chapter_indices 和 stages。
        """
        if not novel.outline.subplots:
            return
        # 分析已有分线交替规律，推断新章节归属
        existing_indices = set()
        for sp in novel.outline.subplots:
            sp_dict = sp.to_dict() if hasattr(sp, "to_dict") else sp
            existing_indices.update(sp_dict.get("chapter_indices", []))
        
        # 获取最后一章所属分线
        last_ch = len(novel.chapters) - n_chapters  # 续写前的最后一章
        last_sp = None
        for sp in novel.outline.subplots:
            sp_dict = sp.to_dict() if hasattr(sp, "to_dict") else sp
            if last_ch in sp_dict.get("chapter_indices", []):
                last_sp = sp
                break
        
        # 交替分配：每2-3章切换一次分线
        subplots_list = novel.outline.subplots
        if len(subplots_list) < 2:
            return
        
        current_sp_idx = 0
        if last_sp:
            for i, sp in enumerate(subplots_list):
                sp_dict = sp.to_dict() if hasattr(sp, "to_dict") else sp
                if sp_dict.get("id") == (last_sp.to_dict().get("id") if hasattr(last_sp, "to_dict") else last_sp.get("id")):
                    current_sp_idx = i
                    break
        
        # 切换到另一分线开始续写
        current_sp_idx = 1 - current_sp_idx
        batch_size = 3  # 每3章切换一次分线
        
        for idx in range(new_start, new_end + 1):
            sp = subplots_list[current_sp_idx]
            sp_dict = sp.to_dict() if hasattr(sp, "to_dict") else sp
            if idx not in sp_dict.get("chapter_indices", []):
                sp_dict.setdefault("chapter_indices", []).append(idx)
            # 每 batch_size 章切换
            if (idx - new_start + 1) % batch_size == 0:
                current_sp_idx = 1 - current_sp_idx
        
        print("[续写] 分线扩展完成: " + str(n_chapters) + " 章已分配到各分线")

    # ---------------- 保存 ----------------
    def _save_novel(self, novel, json_path):
        """更新 json 和 txt（保持平台前缀一致性）。"""
        # 覆盖 json
        json_path.write_text(
            json.dumps(novel.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        # 覆盖 txt（与 json 同名前缀）
        safe_name = "".join(
            ch if (ch.isalnum() or ch in "_-") else "_" for ch in novel.name
        ) or "novel"
        prefix = (self.platform + "_") if self.platform != DEFAULT_PLATFORM else ""
        base = prefix + safe_name
        # 若 json_path 本身已带前缀，则复用其 stem
        if json_path.stem.startswith(self.platform + "_"):
            base = json_path.stem
        txt_path = NOVEL_DIR / (base + ".txt")
        lines = [
            novel.name + "\n",
            "分类：" + novel.category + "  标签：" + str(novel.tags),
            "简介：" + novel.brief + "\n",
        ]
        for ch in novel.chapters:
            lines.append("\n第" + str(ch.index) + "章 " + ch.title + "\n")
            lines.append(ch.content)
            lines.append("")
        txt_path.write_text("\n".join(lines), encoding="utf-8")
        print("[续写] 已保存: " + str(json_path) + " / " + str(txt_path))
