# -*- coding: utf-8 -*-
"""章节写作模块：每个章节是对一个小事件的扩写。

规则（来自架构二.3 与 rules）：
  - 书写当前章节时，需根据前1个章节的标题/大纲/内容 和 后1个章节的标题/大纲 生成。
  - 每个章节内容在 2200-3200 字之间。
  - 符合 事件描述 + 人物形象 + 所在时间 + 所处地点。
  - 不与参考内容太相似；语义通顺、段落合理、避免太AI风格。
"""
from config import (
    CHAPTER_MIN_WORDS, CHAPTER_MAX_WORDS,
    CHAPTER_CONTEXT_BEFORE, CHAPTER_CONTEXT_AFTER,
)
from core.llm_client import LLMClient, get_llm
from core.outline_builder import OutlineBuilder
from models.novel import NovelOutline, Chapter
from storage.libraries import Libraries, library_manager


class ChapterWriter(object):
    """章节写作者。"""

    def __init__(self, llm=None, libs=None, builder=None):
        self.llm = llm or get_llm()
        self.libs = libs or library_manager
        self.builder = builder or OutlineBuilder(self.llm, self.libs)

    # ---------------- 上下文构建 ----------------
    def _gather_context(self, outline, chapter_index):
        """收集前N章与后N章的标题/大纲/内容上下文。"""
        before = []
        for i in range(1, CHAPTER_CONTEXT_BEFORE + 1):
            idx = chapter_index - i
            if idx < 1:
                continue
            s = self.builder.get_small_event_by_chapter(outline, idx)
            before.append({
                "chapter_index": idx,
                "title": s.title if s else "",
                "outline": s.outline if s else "",
                "behavior": s.behavior if s else "",
            })

        after = []
        for i in range(1, CHAPTER_CONTEXT_AFTER + 1):
            idx = chapter_index + i
            s = self.builder.get_small_event_by_chapter(outline, idx)
            if not s:
                continue
            after.append({
                "chapter_index": idx,
                "title": s.title,
                "outline": s.outline,
                "behavior": s.behavior,
            })
        return {"before": before, "after": after}

    def _enrich_event(self, s):
        """用各库信息丰富小事件描述，确保人物/时间/地点一致。

        关键：为参与本章的角色附加其技能/道具/称号的完整效果描述，
        供 LLM 直接参考，避免技能描述/使用不一致。
        """
        parts = []
        parts.append("事件影响：" + s.impact)
        parts.append("事件背景：" + s.background)
        parts.append("人物形象：" + s.character_image)
        parts.append("人物行为：" + s.behavior)
        # 主角
        protos = []
        for pid in s.state.protagonist_ids:
            c = self.libs.characters.get_protagonist(pid)
            if c:
                protos.append(c.name + "（" + c.personality + "）")
        if protos:
            parts.append("主角：" + "；".join(protos))
        # 配角
        sups = []
        for sid in s.state.supporting_ids:
            c = self.libs.characters.get_supporting(sid)
            if c:
                reuse = ("，复用提示：" + c.reuse_hint) if c.reuse_hint else ""
                sups.append(c.name + "（" + (c.background or "配角") + reuse + "）")
        if sups:
            parts.append("配角：" + "；".join(sups))
        # 时间
        tp = self.libs.timeline.get(s.state.time_id)
        if tp:
            parts.append("所处时间：" + tp.name + "（" + tp.description + "）")
        elif s.time_desc:
            parts.append("所处时间：" + s.time_desc)
        # 地点
        loc = self.libs.locations.get(s.state.location_id)
        if loc:
            parts.append("所在地点：" + loc.name + "（" + loc.description + "）状态：" + s.state.location_status)
        elif s.location_desc:
            parts.append("所在地点：" + s.location_desc)
        # === 新增：参与本章角色的技能/道具/称号详情（供 LLM 严格参考） ===
        attr_block = self._build_character_attr_block(s)
        if attr_block:
            parts.append("【本章角色属性参考（写作时必须严格遵循以下技能/道具/称号的效果描述，不得篡改或自创）】")
            parts.append(attr_block)
        return "\n".join(parts)

    def _build_character_attr_block(self, s):
        """构建本章参与角色的技能/道具/称号详情块。

        从 character_library.json 对应属性直接读取，确保描写一致。
        """
        lines = []
        for pid in s.state.protagonist_ids:
            c = self.libs.characters.get_protagonist(pid)
            if not c:
                continue
            summary = c.attr_summary()
            if not summary:
                continue
            lines.append("[主角·" + (c.name or pid) + "]")
            lines.append(summary)
        for sid in s.state.supporting_ids:
            c = self.libs.characters.get_supporting(sid)
            if not c:
                continue
            summary = c.attr_summary()
            if not summary:
                continue
            lines.append("[配角·" + (c.name or sid) + "]")
            lines.append(summary)
        return "\n".join(lines)

    # ---------------- 单章生成 ----------------
    def write_chapter(self, outline, chapter_index, prev_chapters, reference=""):
        """生成指定章节内容。
        
        上下文包括：前一章状态表 + 人物库/地点库/时间库 + 当前章大纲 + 后一章大纲 + 分线上下文。
        """
        s = self.builder.get_small_event_by_chapter(outline, chapter_index)
        if s is None:
            raise ValueError("章节 " + str(chapter_index) + " 没有对应的小事件")

        ctx = self._gather_context(outline, chapter_index)
        event_detail = self._enrich_event(s)
        subplot_prompt = self.builder.build_subplot_prompt(outline, chapter_index)

        # 前一章内容（含状态表）
        prev_content = ""
        if prev_chapters:
            last = prev_chapters[-1]
            prev_s = self.builder.get_small_event_by_chapter(outline, last.index)
            prev_state = ""
            if prev_s:
                prev_state = (
                    "[上一章状态表] 时间ID=" + str(prev_s.state.time_id)
                    + " 地点ID=" + str(prev_s.state.location_id)
                    + " 主角=" + str(prev_s.state.protagonist_ids)
                    + " 配角=" + str(prev_s.state.supporting_ids)
                    + " 地点状态=" + str(prev_s.state.location_status)
                )
            prev_content = (
                prev_state + "\n"
                + "【前一章标题】" + last.title + "\n"
                + "【前一章大纲】" + last.outline + "\n"
                + "【前一章内容摘要】" + last.content[:400]
            )

        before_parts = []
        for i, b_ in enumerate(ctx["before"]):
            before_parts.append("前第" + str(len(ctx["before"]) - i) + "章《" + b_["title"] + "》：" + b_["outline"])
        before_str = "\n".join(before_parts)

        after_parts = []
        for i, a in enumerate(ctx["after"]):
            after_parts.append("后第" + str(i + 1) + "章《" + a["title"] + "》：" + a["outline"])
        after_str = "\n".join(after_parts)

        # 各库摘要
        libs_info = self._build_libraries_prompt()

        system = (
            "你是顶级网络小说写手。你擅长把大纲小事件扩写为高质量章节正文。"
            "要求：1) 严格承接前一章内容/状态，并为后一章埋下铺垫；"
            "2) 体现事件描述+人物形象+所在时间+所处地点；"
            "3) 字数必须处于 2200-3200 字之间；"
            "4) 语言自然流畅，避免太AI腔，段落结构合理；"
            "5) 参考人物库/地点库/时间库确保一致性；"
            "6) 不要与参考作品雷同；7) 不要输出章节标题，只输出正文。"
            "8) 涉及角色的技能、道具、称号描写时，必须严格依据【本章角色属性参考】"
            "中的效果描述来写，不得篡改效果、不得自创新技能/道具/称号、"
            "不得让角色使用其属性库中不存在的技能；技能的冷却时间、持续时间、"
            "作用范围等参数须与库中一致。\n"
            "9) 【分线叙事制——最高优先级】本章须聚焦所属分线的核心事件，"
            "若为分线切换点，须在开头做好自然过渡衔接（时间推移/因果联系/人物心理），"
            "不得生硬跳转。可适当提及另一分线进展作为呼应，但不得喧宾夺主。"
        )
        user = (
            "当前要写第" + str(chapter_index) + "章《" + s.title + "》。\n\n"
            + subplot_prompt + "\n\n"
            "【本章大纲】" + s.outline + "\n"
            "【本章事件详情】\n" + event_detail + "\n\n"
            + prev_content + "\n\n"
            "【前文章节概要】\n" + before_str + "\n\n"
            "【后续章节概要】\n" + after_str + "\n\n"
            + libs_info + "\n\n"
            "【参考信息摘要（勿雷同）】" + reference[:600] + "\n\n"
            "请直接输出第" + str(chapter_index) + "章正文，字数 " +
            str(CHAPTER_MIN_WORDS) + "-" + str(CHAPTER_MAX_WORDS) + " 字。"
        )
        content = self.llm.chat(system, user)
        content = self._polish_length(content)
        return Chapter(
            index=chapter_index,
            title=s.title,
            small_event_id=s.id,
            outline=s.outline,
            content=content,
        )

    def _build_libraries_prompt(self):
        """构建各库参考信息提示（含技能/道具/称号的效果描述）。"""
        lines = ["【人物库/地点库/时间库参考】"]
        for c in self.libs.characters.all_characters():
            details = []
            if c.skill_details():
                details.append("技能[" + "; ".join(c.skill_details()) + "]")
            if c.item_details():
                details.append("道具[" + "; ".join(c.item_details()) + "]")
            if c.title_details():
                details.append("称号[" + "; ".join(c.title_details()) + "]")
            if c.personality:
                details.append("性格:" + c.personality)
            lines.append(
                "角色:" + c.name + "(" + c.role_label + ")"
                + (" " + " ".join(details) if details else "")
            )
        lines.append("---地点---")
        for loc in list(self.libs.locations.locations.values())[:15]:
            lines.append(loc.name + "(" + loc.type + ") " + loc.description[:60])
        lines.append("---时间线---")
        for tp in sorted(self.libs.timeline.points.values(),
                         key=lambda x: x.order)[:15]:
            lines.append(tp.name + " " + tp.description[:60])
        return "\n".join(lines)

    # ---------------- 字数控制 ----------------
    def _polish_length(self, content):
        """统计中文字数，必要时提示补足/精简。"""
        count = len("".join(content.split()))
        if CHAPTER_MIN_WORDS <= count <= CHAPTER_MAX_WORDS:
            return content
        if count < CHAPTER_MIN_WORDS:
            system = "你是网文写手。请在保持原有剧情与人物的前提下，扩写以下章节正文，"
            system += "使总字数达到 " + str(CHAPTER_MIN_WORDS) + "-" + str(CHAPTER_MAX_WORDS) + " 字，不要改变核心情节，只输出正文。"
            user = "当前字数" + str(count) + "，偏少。请扩写：\n\n" + content
            new = self.llm.chat(system, user)
            return new if len("".join(new.split())) > count else content
        # 过长：截取到最后一个完整段落
        if count > CHAPTER_MAX_WORDS:
            trimmed = content
            while len("".join(trimmed.split())) > CHAPTER_MAX_WORDS and "\n" in trimmed:
                trimmed = trimmed.rsplit("\n", 1)[0]
            return trimmed
        return content
