# -*- coding: utf-8 -*-
"""情绪曲线生成器：检测和修正文章内容的情绪曲线。

功能：
  1. 分段：一章正文按 ~1000 字切分为多段
  2. 情绪分析：用 LLM 对每段进行情绪识别与强度打分
  3. 合并：将段级情绪合并为章级情绪值，再合并为全书情绪曲线
  4. 输出：生成情绪曲线数据（可输出文本/JSON），横轴=章节，纵轴=情绪值

用途：
  - 独立运行：python main.py emotion-curve --novel feilu_八零厨神
  - 作为模块：被 generator/continuator 调用，在生成/续写时参考情绪曲线
  - 检测修正：发现情绪平淡（连续低值）或情绪过载（连续极高值）时给出建议

情绪打分模型（0-100）：
  - 情绪类型：平静/期待/紧张/愤怒/悲伤/喜悦/震撼/燃/感动/爽等网文常见情绪
  - 情绪强度：该段情绪波动的剧烈程度
  - 情绪值 = f(情绪类型权重, 情绪强度)
  - 倒 U 型曲线：中等变化幅度得分最高，过低（平淡）或过高（失控）得分降低
"""
import json
import re
from pathlib import Path

from config import NOVEL_DIR
from core.llm_client import LLMClient, get_llm

# 分段目标长度（字）
SEGMENT_TARGET_LENGTH = 1000
# 段间重叠（字），保证情绪连续性
SEGMENT_OVERLAP = 100


# 网文常见情绪类型及其基础权重（影响"爽感"贡献度）
EMOTION_TYPES = {
    "平静": 0.2,
    "期待": 0.5,
    "紧张": 0.7,
    "愤怒": 0.6,
    "悲伤": 0.5,
    "喜悦": 0.6,
    "震撼": 0.8,
    "燃": 0.9,
    "感动": 0.7,
    "爽": 0.9,
    "幽默": 0.5,
    "恐惧": 0.6,
    "反转": 0.8,
    "温情": 0.5,
}


class SegmentEmotion(object):
    """段级情绪分析结果。"""
    def __init__(self, index, text_preview, emotion_type, intensity,
                 value, reason=""):
        self.index = index                  # 段序号（从1开始）
        self.text_preview = text_preview    # 文本预览（前50字）
        self.emotion_type = emotion_type    # 主要情绪类型
        self.intensity = intensity          # 情绪强度（1-10）
        self.value = value                  # 情绪值（0-100）
        self.reason = reason                # LLM 给出的判断理由

    def to_dict(self):
        return {
            "index": self.index,
            "text_preview": self.text_preview,
            "emotion_type": self.emotion_type,
            "intensity": self.intensity,
            "value": self.value,
            "reason": self.reason,
        }


class ChapterEmotion(object):
    """章级情绪分析结果。"""
    def __init__(self, chapter_index, chapter_title, segments, merged_value,
                 dominant_emotion, trend="平稳", advice=""):
        self.chapter_index = chapter_index
        self.chapter_title = chapter_title
        self.segments = segments                      # SegmentEmotion 列表
        self.merged_value = merged_value              # 合并后的章级情绪值
        self.dominant_emotion = dominant_emotion      # 本章主导情绪
        self.trend = trend                            # 情绪走势描述
        self.advice = advice                          # 情绪修正建议

    def to_dict(self):
        return {
            "chapter_index": self.chapter_index,
            "chapter_title": self.chapter_title,
            "merged_value": self.merged_value,
            "dominant_emotion": self.dominant_emotion,
            "trend": self.trend,
            "advice": self.advice,
            "segments": [s.to_dict() for s in self.segments],
        }


class EmotionCurve(object):
    """全书情绪曲线。"""
    def __init__(self, novel_name="", chapters=None):
        self.novel_name = novel_name
        self.chapters = chapters or []  # ChapterEmotion 列表

    @property
    def values(self):
        """返回各章情绪值列表（用于画图）。"""
        return [ch.merged_value for ch in self.chapters]

    @property
    def average(self):
        if not self.chapters:
            return 0
        return sum(self.values) / float(len(self.chapters))

    def to_dict(self):
        return {
            "novel_name": self.novel_name,
            "chapter_count": len(self.chapters),
            "average_value": round(self.average, 1),
            "chapters": [ch.to_dict() for ch in self.chapters],
        }

    def to_text_report(self):
        """生成可读的文本报告。"""
        lines = []
        lines.append("=" * 60)
        lines.append("情绪曲线报告：《" + self.novel_name + "》")
        lines.append("章节数: " + str(len(self.chapters)) +
                     "  平均情绪值: " + str(round(self.average, 1)))
        lines.append("=" * 60)
        # 画简易曲线图
        max_val = max(self.values) if self.values else 100
        for ch in self.chapters:
            bar_len = int(ch.merged_value / 100.0 * 40)
            bar = "#" * bar_len + "-" * (40 - bar_len)
            lines.append(
                "第" + str(ch.chapter_index).rjust(2) + "章 [" +
                bar + "] " + str(ch.merged_value) +
                "  " + ch.dominant_emotion +
                "  " + ch.trend
            )
            if ch.advice:
                lines.append("      → " + ch.advice)
        lines.append("=" * 60)
        # 全局建议
        advice = self._global_advice()
        if advice:
            lines.append("【全局建议】" + advice)
        lines.append("=" * 60)
        return "\n".join(lines)

    def _global_advice(self):
        """分析全局情绪曲线，给出建议。"""
        if len(self.chapters) < 3:
            return ""
        advice_parts = []
        vals = self.values
        # 连续低值（平淡）
        low_streak = 0
        low_start = 0
        for i, v in enumerate(vals):
            if v < 30:
                if low_streak == 0:
                    low_start = i
                low_streak += 1
            else:
                if low_streak >= 3:
                    advice_parts.append(
                        "第" + str(low_start + 1) + "~" + str(low_start + low_streak) +
                        "章连续" + str(low_streak) + "章情绪值偏低（<30），读者可能感到平淡，"
                        "建议在这些章节加入冲突、反转或悬念"
                    )
                low_streak = 0
        if low_streak >= 3:
            advice_parts.append(
                "第" + str(low_start + 1) + "~" + str(low_start + low_streak) +
                "章连续" + str(low_streak) + "章情绪值偏低，建议加入高潮或转折"
            )
        # 连续极高值（过载）
        high_streak = 0
        high_start = 0
        for i, v in enumerate(vals):
            if v > 85:
                if high_streak == 0:
                    high_start = i
                high_streak += 1
            else:
                if high_streak >= 4:
                    advice_parts.append(
                        "第" + str(high_start + 1) + "~" + str(high_start + high_streak) +
                        "章连续" + str(high_streak) + "章情绪值过高（>85），读者可能疲劳，"
                        "建议穿插平静或温情段落调节节奏"
                    )
                high_streak = 0
        # 缺乏高潮
        if max(vals) < 60:
            advice_parts.append(
                "全书最高情绪值仅" + str(max(vals)) +
                "，缺少高潮章节，建议在关键节点加入震撼/燃/爽的高潮段落"
            )
        return " | ".join(advice_parts) if advice_parts else "情绪曲线整体合理，节奏适中"


class EmotionCurveGenerator(object):
    """情绪曲线生成器。

    可独立运行，也可被 generator/continuator 调用。
    """

    def __init__(self, llm=None, segment_length=SEGMENT_TARGET_LENGTH):
        self.llm = llm or get_llm()
        self.segment_length = segment_length

    # ---------------- 分段 ----------------
    def segment_text(self, text):
        """将正文按 ~segment_length 字切分为多段，段间保留重叠。

        按自然段落边界切分，避免段内截断。
        """
        if not text:
            return []
        # 按换行分段
        paragraphs = [p.strip() for p in text.split("\n") if p.strip()]
        if not paragraphs:
            return []
        segments = []
        current = []
        current_len = 0
        for para in paragraphs:
            current.append(para)
            current_len += len(para)
            if current_len >= self.segment_length:
                segments.append("\n".join(current))
                # 保留重叠：最后一个段落带入下一段
                overlap_paras = []
                overlap_len = 0
                for p in reversed(current):
                    if overlap_len + len(p) > SEGMENT_OVERLAP:
                        break
                    overlap_paras.insert(0, p)
                    overlap_len += len(p)
                current = overlap_paras
                current_len = overlap_len
        # 剩余内容
        if current:
            last = "\n".join(current)
            # 若剩余太短则并入上一段
            if segments and len(last) < self.segment_length // 3:
                segments[-1] = segments[-1] + "\n" + last
            else:
                segments.append(last)
        return segments

    # ---------------- 段级情绪分析 ----------------
    def analyze_segment(self, segment, seg_index):
        """用 LLM 分析单段情绪，返回 SegmentEmotion。"""
        preview = segment[:50].replace("\n", " ")
        system = (
            "你是网文情绪分析专家。请分析给定文本段的情绪类型与强度。\n"
            "情绪类型参考：平静/期待/紧张/愤怒/悲伤/喜悦/震撼/燃/感动/爽/幽默/恐惧/反转/温情\n"
            "强度为 1-10 的整数：1=极弱(几乎无情绪波动)，10=极强(剧烈情绪爆发)。\n"
            "情绪值(0-100)的计算规则（倒U型）：\n"
            "  - 强度1-2(平静)：情绪值 10-25\n"
            "  - 强度3-4(微波动)：情绪值 25-45\n"
            "  - 强度5-6(中等波动)：情绪值 45-70（最佳区间）\n"
            "  - 强度7-8(较强波动)：情绪值 60-85\n"
            "  - 强度9-10(剧烈波动)：情绪值 70-95\n"
            "  注意：强度9-10虽剧烈但若过于极端(失控/不合理)，情绪值应适当降低。\n"
            "返回 JSON：{\"emotion_type\":\"\", \"intensity\":1, \"value\":50, \"reason\":\"\"}"
        )
        user = (
            "文本段（第" + str(seg_index) + "段）：\n" + segment[:1200] + "\n\n"
            "请分析此段的情绪类型、强度和情绪值。"
        )
        data = self.llm.chat_json(system, user)
        emotion_type = str(data.get("emotion_type", "平静")).strip()
        # 验证强度范围
        try:
            intensity = int(data.get("intensity", 5))
            intensity = max(1, min(10, intensity))
        except (ValueError, TypeError):
            intensity = 5
        # 验证情绪值范围
        try:
            value = int(data.get("value", 50))
            value = max(0, min(100, value))
        except (ValueError, TypeError):
            value = self._calc_value(emotion_type, intensity)
        reason = str(data.get("reason", "")).strip()
        return SegmentEmotion(
            index=seg_index, text_preview=preview,
            emotion_type=emotion_type, intensity=intensity,
            value=value, reason=reason,
        )

    @staticmethod
    def _calc_value(emotion_type, intensity):
        """根据情绪类型和强度计算情绪值（兜底，LLM 不可用时使用）。"""
        base = EMOTION_TYPES.get(emotion_type, 0.5)
        # 倒U型：强度5-6时值最高
        if intensity <= 2:
            return int(10 + base * 15)
        elif intensity <= 4:
            return int(25 + base * 20)
        elif intensity <= 6:
            return int(45 + base * 25)
        elif intensity <= 8:
            return int(60 + base * 25)
        else:
            return int(70 + base * 20)

    # ---------------- 章级合并 ----------------
    def merge_segments_to_chapter(self, chapter_index, chapter_title, segments):
        """将段级情绪合并为章级情绪，返回 ChapterEmotion。"""
        if not segments:
            return ChapterEmotion(
                chapter_index, chapter_title, [], 50, "平静", "无数据"
            )
        # 合并值：取段级情绪值的加权平均（按段长度权重近似为等权）
        merged_value = sum(s.value for s in segments) / float(len(segments))
        # 主导情绪：出现次数最多的情绪类型
        emo_counts = {}
        for s in segments:
            emo_counts[s.emotion_type] = emo_counts.get(s.emotion_type, 0) + 1
        dominant_emotion = max(emo_counts, key=emo_counts.get) if emo_counts else "平静"
        # 走势分析
        trend = self._analyze_trend(segments)
        # 章级建议
        advice = self._chapter_advice(merged_value, dominant_emotion, segments)
        return ChapterEmotion(
            chapter_index, chapter_title, segments,
            merged_value=round(merged_value, 1),
            dominant_emotion=dominant_emotion,
            trend=trend, advice=advice,
        )

    @staticmethod
    def _analyze_trend(segments):
        """分析段间情绪走势。"""
        if len(segments) < 2:
            return "平稳"
        first_half = sum(s.value for s in segments[:len(segments) // 2]) / (len(segments) // 2)
        second_half = sum(s.value for s in segments[len(segments) // 2:]) / (len(segments) - len(segments) // 2)
        diff = second_half - first_half
        if diff > 15:
            return "上升"
        elif diff < -15:
            return "下降"
        else:
            return "平稳"

    @staticmethod
    def _chapter_advice(merged_value, dominant_emotion, segments):
        """根据章级情绪给出修正建议。"""
        advice_parts = []
        if merged_value < 25:
            advice_parts.append("本章情绪值偏低（" + str(merged_value) + "），情节平淡，"
                                "建议加入冲突或悬念提升情绪张力")
        elif merged_value > 90:
            advice_parts.append("本章情绪值过高（" + str(merged_value) + "），可能过载，"
                                "建议穿插缓冲段落调节节奏")
        # 检查段间突变（相邻段情绪值跳变过大）
        for i in range(1, len(segments)):
            diff = abs(segments[i].value - segments[i - 1].value)
            if diff > 50:
                advice_parts.append(
                    "第" + str(segments[i].index) + "段情绪突跳" + str(diff) +
                    "，衔接可能生硬，建议增加过渡"
                )
                break
        return "；".join(advice_parts)

    # ---------------- 全书情绪曲线 ----------------
    def analyze_chapter(self, content, chapter_index, chapter_title):
        """分析单章情绪，返回 ChapterEmotion。"""
        segments_text = self.segment_text(content)
        print("  第" + str(chapter_index) + "章《" + chapter_title +
              "》: " + str(len(segments_text)) + "段")
        segments = []
        for i, seg in enumerate(segments_text, 1):
            seg_emo = self.analyze_segment(seg, i)
            segments.append(seg_emo)
            print("    段" + str(i) + ": " + seg_emo.emotion_type +
                  " 强度" + str(seg_emo.intensity) + " 值" + str(seg_emo.value))
        return self.merge_segments_to_chapter(chapter_index, chapter_title, segments)

    def analyze_novel(self, novel):
        """分析整本小说的情绪曲线，返回 EmotionCurve。"""
        curve = EmotionCurve(novel_name=novel.name)
        print("[情绪曲线] 开始分析《" + novel.name + "》，共" + str(len(novel.chapters)) + "章")
        for ch in novel.chapters:
            ch_emo = self.analyze_chapter(ch.content, ch.index, ch.title)
            curve.chapters.append(ch_emo)
            print("  → 章级情绪值: " + str(ch_emo.merged_value) +
                  " 主导:" + ch_emo.dominant_emotion +
                  " 走势:" + ch_emo.trend)
        print("[情绪曲线] 分析完成，平均情绪值: " + str(round(curve.average, 1)))
        return curve

    # ---------------- 从文件加载并分析 ----------------
    def analyze_novel_file(self, novel_name, platform=None):
        """从 novels 目录加载小说 JSON 并分析情绪曲线。"""
        from models.novel import Novel
        # 查找文件
        candidates = []
        if platform and platform != "qidian":
            candidates.append(NOVEL_DIR / (platform + "_" + novel_name + ".json"))
        candidates.append(NOVEL_DIR / (novel_name + ".json"))
        # 也尝试模糊匹配
        for p in NOVEL_DIR.glob("*.json"):
            if novel_name in p.name and p not in candidates:
                candidates.append(p)
        path = None
        for c in candidates:
            if c.exists():
                path = c
                break
        if path is None:
            raise FileNotFoundError("小说文件不存在: " + str(candidates))
        data = json.loads(path.read_text(encoding="utf-8"))
        novel = Novel.from_dict(data)
        return self.analyze_novel(novel)

    # ---------------- 输出 ----------------
    def save_curve(self, curve, novel_name):
        """将情绪曲线保存为 JSON 和文本报告。"""
        from config import NOVEL_DIR
        out_dir = NOVEL_DIR / "emotion_curves"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe = "".join(ch if (ch.isalnum() or ch in "_-") else "_" for ch in novel_name)
        # JSON
        json_path = out_dir / (safe + "_emotion_curve.json")
        json_path.write_text(
            json.dumps(curve.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        # 文本报告
        txt_path = out_dir / (safe + "_emotion_curve.txt")
        txt_path.write_text(curve.to_text_report(), encoding="utf-8")
        print("[情绪曲线] 已保存: " + str(json_path))
        print("[情绪曲线] 已保存: " + str(txt_path))
        return json_path, txt_path

    # ---------------- 生成参考（供 generator/continuator 调用） ----------------
    def build_curve_prompt(self, curve):
        """将情绪曲线转为提示文本，供生成/续写参考。"""
        if not curve or not curve.chapters:
            return ""
        lines = ["【已有情绪曲线参考】"]
        lines.append("平均情绪值: " + str(round(curve.average, 1)))
        for ch in curve.chapters[-5:]:  # 最近5章
            lines.append(
                "第" + str(ch.chapter_index) + "章: 值" + str(ch.merged_value) +
                " " + ch.dominant_emotion + " " + ch.trend +
                ("（" + ch.advice + "）" if ch.advice else "")
            )
        # 全局建议
        global_advice = curve._global_advice()
        if global_advice:
            lines.append("【曲线建议】" + global_advice)
        lines.append("【要求】续写时参考上述情绪曲线，保持情绪节奏合理，"
                     "避免连续平淡或连续过载，适当制造起伏。")
        return "\n".join(lines)
