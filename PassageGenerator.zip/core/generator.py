# -*- coding: utf-8 -*-
"""生成器主流程：串联 调研 -> 大纲 -> 章节写作 -> 检查反思 -> 输出。

对应架构二、三，遵循 rules 各级规则。

平台隔离：支持起点/番茄/飞卢等平台，各平台使用独立库与调研产物，
小说文件按平台前缀保存，互不混淆。
"""
import json
import re
from pathlib import Path

from config import NOVEL_DIR, DEFAULT_PLATFORM, NOVEL_PLATFORMS, platform_display_name, RESEARCH_TOP_ALL
from core.chapter_writer import ChapterWriter
from core.checker import NovelChecker
from core.llm_client import LLMClient, get_llm
from core.outline_builder import OutlineBuilder
from core.researcher import Researcher
from models.novel import Novel, Chapter
from storage.libraries import Libraries, library_manager, get_libraries


def _safe_slice(obj, n):
    """安全截断：兼容 str/list/dict/None 等类型，返回字符串。"""
    if obj is None:
        return ""
    if isinstance(obj, str):
        return obj[:n]
    try:
        s = json.dumps(obj, ensure_ascii=False)
        return s[:n]
    except Exception:
        return str(obj)[:n]


class GenerationConfig(object):
    """生成配置。"""
    def __init__(self, category="玄幻", tags=None, chapter_count=10,
                 do_research=True, research_tag=None, reference="", auto_fix=True,
                 platform=DEFAULT_PLATFORM, research_category=None, name=None):
        self.category = category
        self.tags = tags if tags is not None else ["玄幻", "升级"]
        self.chapter_count = chapter_count
        self.do_research = do_research
        self.research_tag = research_tag     # 指定类别标签调研（top2）；None 则走 hot top20
        self.reference = reference           # 参考信息（调研摘要）
        self.auto_fix = auto_fix             # 是否自动修正未通过项
        self.platform = platform if platform in NOVEL_PLATFORMS else DEFAULT_PLATFORM
        # 平台榜单调研时指定的热点分类（如 都市/玄幻）；None 则取综合热点
        self.research_category = research_category
        self.name = name                     # 指定书名（覆盖 LLM 自动生成）


class NovelGenerator(object):
    """小说生成总控。

    platform 决定使用哪套独立库与调研产物，小说文件按平台前缀保存。
    """

    def __init__(self, llm=None, libs=None, platform=DEFAULT_PLATFORM):
        self.llm = llm or get_llm()
        self.platform = platform if platform in NOVEL_PLATFORMS else DEFAULT_PLATFORM
        # 优先使用传入的 libs；否则按平台加载独立库
        self.libs = libs or get_libraries(self.platform)
        self.researcher = Researcher(self.llm)
        self.builder = OutlineBuilder(self.llm, self.libs)
        self.writer = ChapterWriter(self.llm, self.libs, self.builder)
        self.checker = NovelChecker(self.llm, self.libs, self.builder)

    # ---------------- 完整流程 ----------------
    def generate(self, cfg):
        # 返回 (novel, report)
        # 1. 调研（按平台）
        reference = cfg.reference
        if cfg.do_research:
            research = self._do_research(cfg)
            reference = reference or self._summarize_research(research)

        # 2. 基本信息 + 大纲
        meta = self.builder.gen_meta(cfg.category, cfg.tags, reference)
        # 书名覆盖：若配置指定了 name，则使用指定书名
        if cfg.name:
            meta["name"] = cfg.name
        outline = self.builder.build_outline(
            cfg.category, cfg.tags, meta["brief"], cfg.chapter_count, reference
        )
        novel = Novel(
            name=meta["name"], brief=meta["brief"],
            category=meta["category"], tags=list(cfg.tags), outline=outline,
        )

        # 3. 逐章生成（结合前后章节上下文）
        prev_chapters = []
        for idx in sorted(outline.chapter_event_map.keys()):
            chapter = self.writer.write_chapter(outline, idx, prev_chapters, reference)
            novel.chapters.append(chapter)
            prev_chapters.append(chapter)

        # 4. 检查反思
        # 先保存一次拿到路径，注入 checker 让它内部修复也能写回
        path = self._save_novel(novel)
        self.checker._novel_path = path
        report = self.checker.check(novel)
        # 5. 自动修正
        if cfg.auto_fix and not report.passed:
            self._auto_fix(novel, report, reference)
            self.checker._novel_path = path
            report = self.checker.check(novel)
        # 6. 最终持久化（含检查修复后的内容）
        self._save_novel(novel)
        return novel, report

    # ---------------- 调研 ----------------
    def _do_research(self, cfg):
        if cfg.research_tag:
            return self.researcher.research_by_tag(cfg.research_tag)
        # 按平台榜单调研热点分类
        return self.researcher.research_platform_hot(
            self.platform, top=RESEARCH_TOP_ALL, category=cfg.research_category
        )

    def _summarize_research(self, research):
        parts = []
        for it in research.items:
            parts.append(
                "《" + it.name + "》｜分类:" + it.category + "｜标签:" + str(it.tags) + "\n"
                "简介:" + it.brief + "\n大纲摘要:" + _safe_slice(it.outline, 300)
            )
        return "\n---\n".join(parts)

    # ---------------- 自动修正 ----------------
    def _auto_fix(self, novel, report, reference):
        """对明显可修问题（字数/重复/单章问题）进行重写。"""
        issues_by_chapter = {}
        for iss in report.issues:
            m = re.search(r"第(\d+)章", iss)
            if m:
                ci = int(m.group(1))
                issues_by_chapter.setdefault(ci, []).append(iss)

        for ci, issues in issues_by_chapter.items():
            ch = None
            for c in novel.chapters:
                if c.index == ci:
                    ch = c
                    break
            if not ch:
                continue
            issue_str = "; ".join(issues)
            try:
                fixed = self.checker.suggest_fix(ch, issue_str)
                if fixed and len("".join(fixed.split())) > 100:
                    ch.content = fixed
            except Exception as e:  # pragma: no cover
                print("[修正] 第" + str(ci) + "章重写失败: " + str(e))

    # ---------------- 保存 ----------------
    def _save_novel(self, novel):
        NOVEL_DIR.mkdir(parents=True, exist_ok=True)
        safe_name = "".join(
            ch if (ch.isalnum() or ch in "_-") else "_" for ch in novel.name
        ) or "novel"
        # 按平台前缀保存，避免不同平台小说混淆；起点向后兼容无前缀
        prefix = (self.platform + "_") if self.platform != DEFAULT_PLATFORM else ""
        base = prefix + safe_name
        path = NOVEL_DIR / (base + ".json")
        path.write_text(
            json.dumps(novel.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        # 同时输出可读的 txt
        txt_path = NOVEL_DIR / (base + ".txt")
        lines = [novel.name + "\n",
                 "分类：" + novel.category + "  标签：" + str(novel.tags),
                 "简介：" + novel.brief + "\n"]
        for ch in novel.chapters:
            lines.append("\n第" + str(ch.index) + "章 " + ch.title + "\n")
            lines.append(ch.content)
            lines.append("")
        txt_path.write_text("\n".join(lines), encoding="utf-8")
        return path
