# -*- coding: utf-8 -*-
"""大纲构建模块：以事件线为主构建小说大纲。

事件线结构（来自架构二.2）：
  大事件 → 中事件 → 小事件
  小事件 = 事件影响 + 事件背景 + 主角人数(>=1) + 配角人数(0-3)
           + 人物形象 + 人物行为 + 所处时间 + 所在地表状态表
  小事件的转移 = 状态表的转移

同时维护：主角形象库、配角形象库、地点库、时间库。
"""
from config import NOVEL_NAME_MAX, NOVEL_BRIEF_MAX
from core.llm_client import LLMClient, get_llm
from core.character_consistency import CharacterConsistencyChecker
from models.character import Character, CharacterRole
from models.event import EventLibrary
from models.location import Location
from models.novel import NovelOutline, Subplot
from models.timeline import TimePoint
from storage.libraries import Libraries, library_manager

# 大纲单次生成的最大小事件数（超出则分批）
_OUTLINE_BATCH_SIZE = 15


class OutlineBuilder(object):
    """小说大纲构建器。"""

    def __init__(self, llm=None, libs=None):
        self.llm = llm or get_llm()
        self.libs = libs or library_manager
        self.consistency_checker = CharacterConsistencyChecker(self.llm, self.libs)
        # 收集生成过程中的角色冲突（不阻断流程，供上层报告）
        self.character_conflicts = []

    # ---------------- 生成小说基本信息 ----------------
    def gen_meta(self, category, tags, reference=""):
        """生成小说名称(<=10字)、简介(<=100字)、分类。"""
        system = (
            "你是顶级网文策划。根据给定类别与参考信息，构思一部原创网络小说的基本信息。"
            "名称须10字以内，简介须100字以内，避免与参考作品雷同。必须返回 JSON。"
        )
        user = (
            "分类：" + category + "；标签：" + str(tags) + "；参考信息摘要：" + reference[:800] + "\n"
            "请返回 JSON：{\"name\": \"\", \"brief\": \"\", \"category\": \"\"}。"
        )
        data = self.llm.chat_json(system, user)
        name = str(data.get("name", "")).strip()[:NOVEL_NAME_MAX]
        brief = str(data.get("brief", "")).strip()[:NOVEL_BRIEF_MAX]
        cat = str(data.get("category", category)).strip() or category
        if not name:
            name = "未命名小说"
        return {"name": name, "brief": brief, "category": cat}

    # ---------------- 构建事件线大纲 ----------------
    def build_outline(self, category, tags, brief, chapter_count=10, reference=""):
        """构建事件线大纲，并回填各库。章节数较多时自动分批生成。"""
        self.character_conflicts = []
        if chapter_count <= _OUTLINE_BATCH_SIZE:
            event_lib = self._build_outline_single(
                category, tags, brief, 1, chapter_count, reference
            )
        else:
            event_lib = self._build_outline_batched(
                category, tags, brief, chapter_count, reference
            )
        # 回填各库并建立章节-小事件映射
        chapter_map = {}
        for b, m, s in event_lib.iter_small_events():
            self._sync_to_libraries(b, m, s)
            if s.chapter_index is None:
                s.chapter_index = len(chapter_map) + 1
            s.title = self._clean_chapter_title(s.title, s.chapter_index)
            chapter_map[s.chapter_index] = s.id
        self.libs.save()
        # 生成分线结构
        subplots = self._build_subplots(
            category, tags, brief, chapter_count, event_lib, reference
        )
        outline = NovelOutline(
            event_library=event_lib, chapter_event_map=chapter_map,
            subplots=subplots,
        )
        return outline

    def _build_outline_single(self, category, tags, brief, start_idx,
                              end_idx, reference=""):
        """生成一段事件线大纲（start_idx ~ end_idx）。"""
        n = end_idx - start_idx + 1
        system = (
            "你是顶级网文大纲架构师。你以事件线为主构建大纲：大事件→中事件→小事件。"
            "每个小事件必须包含：事件影响、事件背景、主角人数(>=1)、配角人数(0-3)、"
            "人物形象、人物行为、所处时间、所在地点，以及状态表。"
            "小事件的转移即状态表的转移。\n"
            "【分线叙事制——最高优先级】小说采用多分线交替叙事："
            "须设计2条以上分线（如事业线+生活线），一个分线完成一个小阶段后切换到另一分线，"
            "避免读者疲惫。分线切换处须有自然衔接（时间推移/因果联系/人物心理过渡），不得生硬跳转。"
            "每章标题须体现所属分线主题。返回 JSON。"
        )
        user = (
            "类别：" + category + "；标签：" + str(tags) + "；简介：" + brief +
            "；章节范围：第" + str(start_idx) + "章 ~ 第" + str(end_idx) + "章（共" + str(n) + "章）。\n"
            "参考信息摘要：" + reference[:800] + "\n"
            "请生成事件线大纲，chapter_index 从 " + str(start_idx) + " 到 " + str(end_idx) + " 连续递增。"
            "【分线要求】须设计2条以上分线，章节按分线交替排列（如：1-3章A线、4-5章B线、6章A线...），"
            "切换处须有过渡铺垫。每条分线在 small_event 的 outline 字段开头标注 [分线名]。\n"
            "返回 JSON 结构：\n"
            "{\n"
            '  "big_events": [\n'
            '    {"id":"B1","title":"","summary":"",\n'
            '     "middle_events":[\n'
            '       {"id":"B1M1","title":"","summary":"",\n'
            '        "small_events":[\n'
            '          {"id":"xx","title":"第"章 标题",\n'
            '           "impact":"","background":"",\n'
            '           "protagonist_count":1,"supporting_count":0,\n'
            '           "character_ids":["male_lead"],\n'
            '           "character_image":"","behavior":"",\n'
            '           "time_desc":"","location_desc":"",\n'
            '           "state":{"time_id":"","location_id":"",\n'
            '            "protagonist_ids":["male_lead"],"supporting_ids":[],\n'
            '            "character_states":{},"location_status":""},\n'
            '           "outline":"","chapter_index":1}\n'
            '        ]}\n'
            '     ]}\n'
            "  ],\n"
            '  "subplots": [\n'
            '    {"id":"line_a","name":"分线A名称","description":"分线A描述",\n'
            '     "chapter_indices":[1,2,3],\n'
            '     "stages":[{"name":"阶段名","chapters":[1,2],"summary":"阶段叙述"}]}\n'
            "  ]\n"
            "}\n"
            "要求：chapter_index 严格从 " + str(start_idx) + " 到 " + str(end_idx) +
            "；时间与地点保持前后连贯；状态表反映小事件转移；"
            "分线交替推进，切换处衔接自然。"
        )
        data = self.llm.chat_json(system, user)
        event_lib = EventLibrary.from_dict({"big_events": data.get("big_events", [])})
        # 缓存 LLM 返回的分线结构，供 build_outline 使用
        self._last_subplots_raw = data.get("subplots", [])
        return event_lib

    def _build_outline_batched(self, category, tags, brief, chapter_count, reference):
        """分批生成大纲并合并。"""
        import math
        batches = int(math.ceil(float(chapter_count) / _OUTLINE_BATCH_SIZE))
        print("  [大纲] 分" + str(batches) + "批生成（每批≤" + str(_OUTLINE_BATCH_SIZE) + "章）...")
        all_small = []
        big_title = ""
        big_summary = ""
        mid_title = ""
        mid_summary = ""
        for b in range(batches):
            start = b * _OUTLINE_BATCH_SIZE + 1
            end = min((b + 1) * _OUTLINE_BATCH_SIZE, chapter_count)
            print("  [大纲] 第" + str(b + 1) + "/" + str(batches) + "批：第" + str(start) + "~" + str(end) + "章")
            lib = self._build_outline_single(category, tags, brief, start, end, reference)
            for bg, md, sm in lib.iter_small_events():
                if not big_title and bg.title:
                    big_title = bg.title
                    big_summary = bg.summary
                if not mid_title and md.title:
                    mid_title = md.title
                    mid_summary = md.summary
                sm.chapter_index = sm.chapter_index or (len(all_small) + 1)
                all_small.append(sm)
        if not big_title:
            big_title = "主线"
        if not mid_title:
            mid_title = "正篇"
        from models.event import MiddleEvent, BigEvent
        big_event = BigEvent(
            id="B1", title=big_title, summary=big_summary,
            middle_events=[MiddleEvent(
                id="B1M1", title=mid_title, summary=mid_summary,
                small_events=all_small,
            )],
        )
        return EventLibrary(big_events=[big_event])

    def _build_subplots(self, category, tags, brief, chapter_count, event_lib, reference=""):
        """构建分线结构。

        优先使用 LLM 在大纲生成时返回的分线；若无则根据事件线内容自动推断。
        返回 Subplot 对象列表。
        """
        # 优先使用 LLM 返回的分线结构
        raw_subplots = getattr(self, "_last_subplots_raw", None)
        if raw_subplots and isinstance(raw_subplots, list) and len(raw_subplots) >= 2:
            subplots = []
            for sp_data in raw_subplots:
                if isinstance(sp_data, dict) and sp_data.get("name"):
                    subplots.append(Subplot(
                        id=sp_data.get("id", ""),
                        name=sp_data.get("name", ""),
                        description=sp_data.get("description", ""),
                        chapter_indices=sp_data.get("chapter_indices", []),
                        stages=sp_data.get("stages", []),
                    ))
            if len(subplots) >= 2:
                self._last_subplots_raw = None
                return subplots

        # 兜底：让 LLM 根据已生成的事件线推断分线
        return self._infer_subplots_from_events(category, tags, brief, chapter_count, event_lib)

    def _infer_subplots_from_events(self, category, tags, brief, chapter_count, event_lib):
        """根据已生成的事件线，让 LLM 推断分线结构。"""
        # 收集所有小事件的标题与大纲
        events_summary = []
        for b, m, s in event_lib.iter_small_events():
            events_summary.append(
                "第" + str(s.chapter_index) + "章《" + str(s.title) + "》: " + str(s.outline)[:100]
            )
        events_text = "\n".join(events_summary[:30])

        system = (
            "你是顶级网文策划。请根据已生成的章节大纲，为小说设计分线结构。"
            "要求设计2条分线，各分线交替推进（一个分线完成小阶段后切换到另一分线），"
            "切换处衔接自然。返回 JSON。"
        )
        user = (
            "小说简介：" + brief + "；分类：" + category + "；标签：" + str(tags) + "\n"
            "共" + str(chapter_count) + "章，章节大纲如下：\n" + events_text + "\n\n"
            "请设计2条分线，返回 JSON：\n"
            '{"subplots":[{"id":"line_a","name":"分线A","description":"描述",'
            '"chapter_indices":[1,2],"stages":[{"name":"阶段","chapters":[1,2],"summary":""}]}]}'
        )
        data = self.llm.chat_json(system, user)
        raw = data.get("subplots", [])
        subplots = []
        for sp_data in raw:
            if isinstance(sp_data, dict) and sp_data.get("name"):
                subplots.append(Subplot(
                    id=sp_data.get("id", ""),
                    name=sp_data.get("name", ""),
                    description=sp_data.get("description", ""),
                    chapter_indices=sp_data.get("chapter_indices", []),
                    stages=sp_data.get("stages", []),
                ))
        return subplots

    @staticmethod
    def _clean_chapter_title(title, chapter_index):
        """去除章节标题开头重复的"第N章/第N回"前缀。

        模型常生成 "第一章 觉醒" 这类带编号的标题，而显示时会再拼一次"第N章"，
        导致 "第1章《第一章 觉醒》"。这里剥离前缀，仅保留名称部分。
        """
        import re
        if not title:
            return "第" + str(chapter_index) + "章"
        # 匹配开头的 "第X章/回/节" 前缀（X 可为中文数字、阿拉伯数字、罗马数字）
        m = re.match(r"^第[0-9一二三四五六七八九十百千零两]+[章回节卷][\s:：、·\-]*", title)
        if m:
            name = title[m.end():].strip()
            return name if name else title
        return title.strip()

    # ---------------- 回填各库 ----------------
    def _sync_to_libraries(self, b, m, s):
        """根据小事件信息回填主角/配角/地点/时间库。

        新增角色时扫描 character_library.json，检测新角色是否与已有角色
        干了同一件事（认知污染/大纲污染/角色不一致）。
        """
        # 时间
        if s.state.time_id:
            if not self.libs.timeline.get(s.state.time_id):
                self.libs.timeline.add(TimePoint(
                    id=s.state.time_id,
                    name=s.time_desc or s.state.time_id,
                    description=s.time_desc,
                    order=s.chapter_index or 0,
                ))
        # 地点
        if s.state.location_id:
            if not self.libs.locations.get(s.state.location_id):
                self.libs.locations.add(Location(
                    id=s.state.location_id,
                    name=s.location_desc or s.state.location_id,
                    description=s.location_desc,
                ))
        # 主角
        for pid in s.state.protagonist_ids:
            if not self.libs.characters.get_protagonist(pid):
                new_char = Character(
                    id=pid, name=pid, role=CharacterRole.PROTAGONIST,
                    role_label="主角", personality=s.character_image,
                )
                # 新增前检测与已有角色的行为冲突
                self._check_and_record_conflict(new_char, s)
                self.libs.characters.add_protagonist(new_char)
        # 配角
        for sid in s.state.supporting_ids:
            if not self.libs.characters.get_supporting(sid):
                new_char = Character(
                    id=sid, name=sid, role=CharacterRole.SUPPORTING,
                    role_label="配角",
                    last_appear_time=s.state.time_id,
                    last_appear_location=s.state.location_id,
                )
                # 新增前检测与已有角色的行为冲突
                self._check_and_record_conflict(new_char, s)
                self.libs.characters.add_supporting(new_char)

    def _check_and_record_conflict(self, new_char, small_event):
        """检测新角色与已有角色的行为冲突，记录到 self.character_conflicts。

        检测不阻断流程，仅记录报告；冲突时打印警告供人工/上层处理。
        """
        try:
            sub = self.consistency_checker.check_new_character(new_char, small_event)
            for c in sub.conflicts:
                self.character_conflicts.append(c)
                print(
                    "[角色冲突警告] 新角色「" + str(c["new_name"]) +
                    "」与已有角色「" + str(c["existing_name"]) +
                    "」疑似行为重复（相似度 " + str(round(c["similarity"], 2)) +
                    "）：" + str(c["reason"])
                )
                if c.get("suggestion"):
                    print("  → 区分建议: " + str(c["suggestion"]))
        except Exception as e:  # pragma: no cover
            print("[角色冲突检测] 跳过（" + str(e) + "）")

    # ---------------- 章节标题与小事件对应 ----------------
    def get_small_event_by_chapter(self, outline, chapter_index):
        sid = outline.chapter_event_map.get(chapter_index)
        if not sid:
            return None
        for _, _, s in outline.event_library.iter_small_events():
            if s.id == sid:
                return s
        return None

    def get_subplot_of_chapter(self, outline, chapter_index):
        """获取指定章节所属的分线信息，返回 (subplot, is_switch_point)。

        is_switch_point 表示该章是否为分线切换点（即前一章属于不同分线）。
        """
        current_sp = None
        prev_sp = None
        for sp in outline.subplots:
            if chapter_index in sp.chapter_indices:
                current_sp = sp
            if (chapter_index - 1) in sp.chapter_indices:
                prev_sp = sp
        is_switch = False
        if current_sp and prev_sp and current_sp.id != prev_sp.id:
            is_switch = True
        return current_sp, is_switch

    def build_subplot_prompt(self, outline, chapter_index):
        """构建分线上下文提示文本，供章节写作使用。"""
        sp, is_switch = self.get_subplot_of_chapter(outline, chapter_index)
        if not sp:
            return ""
        parts = ["【分线信息】"]
        parts.append("当前分线：" + sp.name + "（" + sp.id + "）")
        parts.append("分线描述：" + sp.description[:200])
        # 阶段信息
        for stage in sp.stages:
            if chapter_index in stage.get("chapters", []):
                parts.append("所处阶段：" + stage.get("name", "") + " - " + stage.get("summary", "")[:100])
                break
        if is_switch:
            # 找到上一章所属分线
            prev_sp_name = ""
            for p in outline.subplots:
                if (chapter_index - 1) in p.chapter_indices:
                    prev_sp_name = p.name
                    break
            parts.append(
                "【分线切换提示】本章从「" + prev_sp_name + "」切换到「" + sp.name +
                "」，须在开头做好自然过渡衔接（时间推移/因果联系/人物心理），不得生硬跳转。"
            )
        return "\n".join(parts)

    def ordered_small_events(self, outline):
        """按章节顺序返回小事件。"""
        result = []
        for idx in sorted(outline.chapter_event_map.keys()):
            s = self.get_small_event_by_chapter(outline, idx)
            if s:
                result.append((idx, s))
        return result
