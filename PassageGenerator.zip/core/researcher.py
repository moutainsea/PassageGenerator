# -*- coding: utf-8 -*-
"""调研模块：获取当前最热网文信息并存为 json。

功能（来自架构一）：
  1. 按当前时间查询，获取最热 top 20 小说信息 -> {timestamp}_hot20.json
  2. 按小说类别标签查询，获取最热 top 2 小说信息 -> {timestamp}_{tag}.json
     （章节名称、大纲为超详细）
  3. 按平台榜单查询热点分类 -> {timestamp}_{platform_code}_hot.json
     支持起点/番茄/飞卢等不同平台，调研产物互不混淆。
"""
import json
from datetime import datetime
from pathlib import Path

from config import RESEARCH_TOP_ALL, RESEARCH_TOP_BY_TAG, NOVEL_PLATFORMS
from core.llm_client import LLMClient, get_llm
from storage.research_store import (
    ResearchResult, ResearchStore, NovelResearchItem,
)


class Researcher(object):
    """最热小说调研器。"""

    def __init__(self, llm=None, store=None):
        self.llm = llm or get_llm()
        self.store = store or ResearchStore()

    # ---------------- 按时间查询 top 20 ----------------
    def research_hot_top(self, top=None, expand=False):
        """按当前时间查询最热 top N（默认2）小说。

        默认 top 2，避免调研过宽导致后续生成时 LLM 参考信息太杂、写岔劈。
        需更多调研时可显式传入 top=N。
        expand: 是否对 top 2 扩充超详细大纲。
        """
        top = top or RESEARCH_TOP_BY_TAG  # 默认 top 2
        now = datetime.now().strftime("%Y-%m")
        system = (
            "你是一名资深网文行业分析师。你的任务是根据当前时间，"
            "列出当下热度最高的网络小说。必须返回 JSON。"
        )
        user = (
            "当前时间是 " + now + "。请给出当下热度最高的 " + str(top) +
            " 部网络小说，每部包含字段：name(小说名称)、brief(简介)、category(分类)、"
            "tags(类别标签数组)、chapter_names(代表性章节名称数组)、"
            "outline(详细大纲)、heat(热度数值)、source(来源平台)。\n"
            "返回 JSON：{\"items\": [ ...共" + str(top) + "条... ]}。"
        )
        data = self.llm.chat_json(system, user)
        items = self._parse_items(data)
        # 扩充模式：基于 top 2 补充每部作品超详细大纲
        if expand and items:
            for it in items:
                it.outline = self._expand_outline(it, "起点", "起点畅销榜")
        result = ResearchResult(
            query_type="hot20",
            timestamp=datetime.now().strftime("%Y%m%d_%H%M%S"),
            items=items,
            remark="按时间查询最热top" + str(top) + (", 已扩充大纲" if expand else ""),
        )
        self.store.save(result)
        return result

    # ---------------- 按类别标签查询 top 2 ----------------
    def research_by_tag(self, tag, top=None):
        """按小说类别标签查询最热 top N（默认2）小说，大纲需超详细。"""
        top = top or RESEARCH_TOP_BY_TAG
        system = (
            "你是一名资深网文行业分析师。你的任务是根据给定的小说类别标签，"
            "列出该类别下热度最高的网络小说，并给出超详细大纲。必须返回 JSON。"
        )
        user = (
            "小说类别标签：" + tag + "。请给出该类别下热度最高的 " + str(top) +
            " 部网络小说，每部包含字段：name、brief、category、tags、"
            "chapter_names(章节名称数组)、outline(超详细大纲，包含主线脉络与关键转折)、"
            "heat、source。\n"
            "返回 JSON：{\"items\": [ ...共" + str(top) + "条... ]}。"
        )
        data = self.llm.chat_json(system, user)
        items = self._parse_items(data)
        safe_tag = "".join(
            ch if (ch.isalnum() or ch in "_-") else "_" for ch in tag
        ) or "tag"
        result = ResearchResult(
            query_type=safe_tag,
            timestamp=datetime.now().strftime("%Y%m%d_%H%M%S"),
            items=items,
            remark="按类别标签[" + tag + "]查询最热top" + str(top),
        )
        self.store.save(result)
        return result

    # ---------------- 按平台榜单查询热点分类 ----------------
    def research_platform_hot(self, platform, top=None, category=None, expand=False):
        """调研指定平台榜单的热点分类小说。

        platform: 平台代码（qidian/fanqie/feilu）
        top: 取前N部（默认2，避免调研过宽导致后续生成写岔劈）
        category: 可选，指定热点分类（如 都市/玄幻）；不指定则取该榜单综合热点
        expand: 是否在 top 2 基础上扩充每部作品的超详细大纲
        调研产物文件名带平台标识：{timestamp}_{platform}_hot.json
        """
        top = top or RESEARCH_TOP_BY_TAG  # 默认 top 2（与架构一.2 一致）
        info = NOVEL_PLATFORMS.get(platform)
        if not info:
            raise ValueError("未知平台: " + str(platform))
        rank_name = info["rank_name"]
        plat_name = info["name"]
        now = datetime.now().strftime("%Y-%m")
        scope = ("热点分类[" + category + "]下") if category else "综合热点"
        system = (
            "你是一名资深网文行业分析师，熟悉" + plat_name +
            "的小说榜单生态。你的任务是调研" + rank_name +
            "当下的热点分类与高热度作品，必须返回 JSON。"
        )
        user = (
            "当前时间是 " + now + "。请调研" + rank_name + "的" + scope +
            "热度最高的 " + str(top) + " 部网络小说。\n"
            "要求：1) 作品须为" + plat_name + "平台的真实/典型高热度作品风格；"
            "2) 每部包含字段：name、brief、category(分类)、tags(类别标签数组)、"
            "chapter_names(代表性章节名称数组)、outline(详细大纲，含主线脉络与关键转折)、"
            "heat(热度数值)、source(固定为\"" + plat_name + "\")；"
            "3) 重点提炼该平台当前的热点分类趋势。\n"
            "返回 JSON：{\"items\": [ ...共" + str(top) + "条... ]}。"
        )
        data = self.llm.chat_json(system, user)
        items = self._parse_items(data)
        # 强制标注来源平台，避免不同平台调研混淆
        for it in items:
            it.source = plat_name
        # 扩充模式：基于 top 2 补充每部作品超详细大纲
        if expand and items:
            for it in items:
                it.outline = self._expand_outline(it, plat_name, rank_name)
        query_type = platform + "_hot" + ("_" + "".join(
            ch if (ch.isalnum() or ch in "_-") else "_" for ch in (category or "")
        ) if category else "")
        result = ResearchResult(
            query_type=query_type,
            timestamp=datetime.now().strftime("%Y%m%d_%H%M%S"),
            items=items,
            remark="按平台[" + plat_name + "/" + rank_name + "]" + scope +
            "查询最热top" + str(top) + (", 已扩充大纲" if expand else ""),
        )
        self.store.save(result)
        return result

    def _expand_outline(self, item, plat_name, rank_name):
        """基于已有大纲，调用 LLM 生成超详细扩充版大纲。

        包含：主线脉络、主要事件线、关键转折、人物关系、力量体系、热点元素等。
        """
        system = (
            "你是顶级网文策划。给定一部小说的基础信息，请基于其当前大纲扩充出"
            "超详细大纲（含主线脉络、核心人物、主要事件线、关键转折、力量体系、"
            "读者爽点节奏），便于后续仿写参考。"
            "必须返回 JSON：{\"expanded_outline\": \"超详细大纲文本\"}。"
        )
        user = (
            "平台：" + plat_name + "（" + rank_name + "）\n"
            "作品名：《" + item.name + "》\n"
            "分类：" + item.category + "  标签：" + str(item.tags) + "\n"
            "简介：" + item.brief + "\n"
            "基础大纲：" + (item.outline or "无") + "\n"
            "代表性章节：" + ", ".join(item.chapter_names) + "\n\n"
            "请扩充为超详细大纲（2000字以上），覆盖："
            "1) 主线脉络与核心设定；2) 主角成长路径与关键转折节点；"
            "3) 主要人物关系与阵营；4) 力量/技能/等级体系；"
            "5) 典型情节套路与读者爽点；6) 该作品值得仿写的核心元素。"
        )
        data = self.llm.chat_json(system, user)
        expanded = data.get("expanded_outline", "")
        # 兼容 LLM 直接返回字符串
        if not expanded and data.get("_raw"):
            expanded = str(data["_raw"])
        if not expanded:
            expanded = item.outline
        return expanded

    # ---------------- 外部注入（离线/手动） ----------------
    def import_from_file(self, path):
        """从已有 json 文件导入调研结果。"""
        return self.store.load(path)

    # ---------------- 工具 ----------------
    @staticmethod
    def _parse_items(data):
        import json as _json
        raw = data.get("items", [])
        if isinstance(raw, dict):
            raw = [raw]
        items = []
        for r in raw:
            if not isinstance(r, dict):
                continue
            # 规范化 outline 字段：list/dict 转为字符串，便于后续截断
            if "outline" in r and not isinstance(r["outline"], str):
                try:
                    r["outline"] = _json.dumps(r["outline"], ensure_ascii=False)
                except Exception:
                    r["outline"] = str(r["outline"])
            items.append(NovelResearchItem.from_dict(r))
        return items

    def list_history(self):
        return self.store.list_files()
