# -*- coding: utf-8 -*-
"""角色一致性检测模块：防止新增角色与已有角色干同一件事。

场景（对应架构二.2 与 rules）：
  - 续写/生成新章节时，新角色可能"认知污染"已有角色——
    新角色和旧角色干了同一件事、拥有相同定位/行为/背景，导致
    大纲污染、角色不一致。
  - 本模块在新增角色入库前进行扫描，发现冲突则报告并给出修复建议。

两阶段检测：
  1. 文本相似度预筛（零成本）：对比 behavior/character_image/background
     的关键词重叠度，筛出候选冲突对。
  2. LLM 精确判断（仅对候选对）：让模型判断是否真的构成"同一件事"重复。
"""
import re

from core.llm_client import get_llm
from storage.libraries import library_manager


# 关键词提取：去掉停用词与标点，保留有意义的 2 字以上词组
_STOP_WORDS = set([
    "的", "了", "是", "在", "和", "与", "及", "或", "也", "都", "而", "但",
    "他", "她", "它", "我", "你", "们", "这", "那", "一个", "一名", "一些",
    "被", "把", "让", "向", "从", "到", "为", "对", "于", "由", "给", "跟",
    "着", "过", "中", "上", "下", "里", "外", "后", "前", "并", "又", "再",
    "已", "正", "将", "会", "能", "可", "可以", "应", "应该", "需要", "进行",
])


def _tokenize(text):
    """简易分词：按非汉字字符切分，过滤停用词与单字。"""
    if not text:
        return set()
    # 按非汉字/非字母数字切分
    chunks = re.split(r"[^\u4e00-\u9fa5A-Za-z0-9]+", text)
    tokens = set()
    for ch in chunks:
        ch = ch.strip()
        if not ch or ch in _STOP_WORDS:
            continue
        if len(ch) <= 1:
            continue
        tokens.add(ch)
        # 额外切出 2-3 字子串，提升召回
        if len(ch) >= 3:
            for i in range(len(ch) - 1):
                seg = ch[i:i + 2]
                if seg not in _STOP_WORDS and len(seg) >= 2:
                    tokens.add(seg)
    return tokens


def _jaccard(set_a, set_b):
    """计算两个集合的 Jaccard 相似度。"""
    if not set_a or not set_b:
        return 0.0
    inter = len(set_a & set_b)
    union = len(set_a | set_b)
    return inter / float(union) if union else 0.0


def _char_behavior_text(c):
    """汇总角色的行为定位文本，用于相似度比较。"""
    parts = []
    if c.personality:
        parts.append(c.personality)
    if c.background:
        parts.append(c.background)
    if c.experience:
        parts.append(c.experience)
    if c.reuse_hint:
        parts.append(c.reuse_hint)
    return " ".join(parts)


class ConflictReport(object):
    """角色冲突检测报告。"""
    def __init__(self):
        self.conflicts = []      # [{new_id, new_name, existing_id, existing_name,
                                 #   reason, similarity, suggestion}]
        self.passed = True

    def add(self, new_id, new_name, existing_id, existing_name,
            reason, similarity=0.0, suggestion=""):
        self.conflicts.append({
            "new_id": new_id,
            "new_name": new_name,
            "existing_id": existing_id,
            "existing_name": existing_name,
            "reason": reason,
            "similarity": similarity,
            "suggestion": suggestion,
        })
        self.passed = False


class CharacterConsistencyChecker(object):
    """角色一致性检查器。"""

    # 文本预筛相似度阈值（超过则送 LLM 精判）
    PRESCREEN_THRESHOLD = 0.25

    def __init__(self, llm=None, libs=None):
        self.llm = llm or get_llm()
        self.libs = libs or library_manager

    # ---------------- 单角色 vs 库 ----------------
    def check_new_character(self, new_char, small_event=None):
        """检查单个新角色是否与已有角色行为重复。

        new_char: Character 实例（尚未入库或刚入库的新角色）
        small_event: 可选，该角色出现的小事件，提供 behavior 上下文
        返回 ConflictReport。
        """
        report = ConflictReport()
        new_behavior = _char_behavior_text(new_char)
        if small_event is not None:
            if small_event.behavior:
                new_behavior += " " + small_event.behavior
            if small_event.character_image:
                new_behavior += " " + small_event.character_image
        new_tokens = _tokenize(new_behavior)
        if not new_tokens:
            return report

        # 与所有已有角色比对
        candidates = []
        for existing in self.libs.characters.all_characters():
            if existing.id == new_char.id:
                continue
            existing_behavior = _char_behavior_text(existing)
            existing_tokens = _tokenize(existing_behavior)
            sim = _jaccard(new_tokens, existing_tokens)
            if sim >= self.PRESCREEN_THRESHOLD:
                candidates.append((existing, sim, existing_behavior))

        if not candidates:
            return report

        # 按相似度排序，取 top 5 送 LLM 精判
        candidates.sort(key=lambda x: x[1], reverse=True)
        for existing, sim, existing_behavior in candidates[:5]:
            conflict = self._llm_judge_conflict(
                new_char, new_behavior, existing, existing_behavior,
                small_event, sim
            )
            if conflict:
                report.add(
                    new_id=new_char.id, new_name=new_char.name,
                    existing_id=existing.id, existing_name=existing.name,
                    reason=conflict.get("reason", ""),
                    similarity=sim,
                    suggestion=conflict.get("suggestion", ""),
                )
        return report

    def _llm_judge_conflict(self, new_char, new_behavior, existing_char,
                            existing_behavior, small_event, similarity):
        """用 LLM 判断两个角色是否构成行为重复（同一件事）。"""
        context = ""
        if small_event is not None:
            context = (
                "新角色所在小事件行为：" + (small_event.behavior or "") + "\n"
                "新角色形象描述：" + (small_event.character_image or "") + "\n"
            )
        system = (
            "你是严谨的网文角色审查员。判断两个角色是否构成'同一件事'的重复"
            "（认知污染/大纲污染/角色不一致）。判定标准：两个角色的行为定位、"
            "功能职责、剧情作用高度雷同，例如都是'拦下主角的执法者'、都是'提供"
            "线索的线人'、都是'同类型敌人'且无可区分的特征。若两人只是职业相同"
            "但有不同剧情作用，则不算冲突。返回 JSON："
            "{\"conflict\": bool, \"reason\": \"\", \"suggestion\": \"\"}。"
            "suggestion 给出如何区分两者（如调整新角色的立场/动机/能力/出场场景）。"
        )
        user = (
            "新角色：" + new_char.name + "（" + (new_char.role_label or "新角色") + "）\n"
            "新角色行为/背景：" + new_behavior[:300] + "\n"
            + context + "\n"
            "已有角色：" + existing_char.name + "（" + (existing_char.role_label or "角色") + "）\n"
            "已有角色行为/背景：" + existing_behavior[:300] + "\n\n"
            "文本预筛相似度：" + str(round(similarity, 2)) + "\n"
            "请判断新角色是否与已有角色干了同一件事（行为/定位重复）。"
        )
        data = self.llm.chat_json(system, user)
        if data.get("conflict"):
            return {
                "reason": str(data.get("reason", "行为/定位重复")),
                "suggestion": str(data.get("suggestion", "")),
            }
        return None

    # ---------------- 批量：续写新大纲 ----------------
    def scan_new_characters(self, new_small_events, novel=None):
        """扫描一批新小事件中的新增角色，检测与已有角色的冲突。

        new_small_events: 新生成的小事件列表 [SmallEvent]
        novel: 可选，提供已有章节上下文
        返回 ConflictReport。
        """
        report = ConflictReport()
        # 收集已有角色 id 集合
        existing_ids = set()
        for c in self.libs.characters.all_characters():
            existing_ids.add(c.id)

        for s in new_small_events:
            # 主角
            for pid in s.state.protagonist_ids:
                if pid in existing_ids:
                    continue
                from models.character import Character, CharacterRole
                new_char = Character(
                    id=pid, name=pid, role=CharacterRole.PROTAGONIST,
                    role_label="主角",
                    personality=s.character_image or "",
                )
                sub = self.check_new_character(new_char, s)
                for c in sub.conflicts:
                    report.conflicts.append(c)
                    report.passed = False
                existing_ids.add(pid)
            # 配角
            for sid in s.state.supporting_ids:
                if sid in existing_ids:
                    continue
                from models.character import Character, CharacterRole
                new_char = Character(
                    id=sid, name=sid, role=CharacterRole.SUPPORTING,
                    role_label="配角",
                    last_appear_time=s.state.time_id,
                    last_appear_location=s.state.location_id,
                )
                sub = self.check_new_character(new_char, s)
                for c in sub.conflicts:
                    report.conflicts.append(c)
                    report.passed = False
                existing_ids.add(sid)
        return report
