# -*- coding: utf-8 -*-
"""跨平台去重检查：确保不同平台（如番茄 vs 飞卢）生成的小说互不重复。

检测维度：
  1. 小说名称重复/高度相似
  2. 章节标题重复/高度相似
  3. 章节正文 n-gram 相似度过高
  4. 大纲/简介雷同

用法：
  report = CrossPlatformChecker().check("fanqie", "feilu")
  if not report.passed:
      # 对冲突章节进行重写
"""
import json
import re
from pathlib import Path

from config import NOVEL_DIR, DEFAULT_PLATFORM


def _ngrams(text, n=8):
    """提取文本的 n-gram 集合（用于相似度比较）。"""
    t = "".join(text.split())
    if len(t) < n:
        return set([t]) if t else set()
    return set(t[i:i + n] for i in range(len(t) - n + 1))


def _jaccard(set_a, set_b):
    if not set_a or not set_b:
        return 0.0
    inter = len(set_a & set_b)
    union = len(set_a | set_b)
    return inter / float(union) if union else 0.0


def _title_sim(a, b):
    """章节标题相似度：基于字符重叠。"""
    if not a or not b:
        return 0.0
    sa, sb = set(a), set(b)
    return _jaccard(sa, sb)


class CrossPlatformReport(object):
    """跨平台去重报告。"""
    def __init__(self):
        self.passed = True
        self.conflicts = []  # [{type, platform_a, platform_b, detail}]

    def add(self, conflict_type, platform_a, platform_b, detail):
        self.conflicts.append({
            "type": conflict_type,
            "platform_a": platform_a,
            "platform_b": platform_b,
            "detail": detail,
        })
        self.passed = False


class CrossPlatformChecker(object):
    """跨平台小说去重检查器。"""

    # 相似度阈值
    NAME_SIM_THRESHOLD = 0.6      # 书名相似度
    TITLE_SIM_THRESHOLD = 0.7     # 章节标题相似度
    CONTENT_SIM_THRESHOLD = 0.5   # 正文相似度

    def __init__(self, llm=None):
        self.llm = llm

    # ---------------- 加载平台小说 ----------------
    def _load_platform_novels(self, platform):
        """加载指定平台下的所有小说（返回 [(novel_dict, path), ...]）。"""
        novels = []
        prefix = (platform + "_") if platform != DEFAULT_PLATFORM else ""
        for p in sorted(NOVEL_DIR.glob("*.json")):
            # 跳过 txt
            if p.suffix != ".json":
                continue
            # 平台匹配：带前缀的归该平台；起点的无前缀也归起点
            if prefix:
                if not p.stem.startswith(prefix):
                    continue
            else:
                # 起点平台：排除带其他平台前缀的
                if any(p.stem.startswith(code + "_") for code in ("fanqie", "feilu")):
                    continue
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                novels.append((data, p))
            except Exception:
                continue
        return novels

    # ---------------- 主检查 ----------------
    def check(self, platform_a, platform_b):
        """检查两个平台的所有小说是否重复。"""
        report = CrossPlatformReport()
        novels_a = self._load_platform_novels(platform_a)
        novels_b = self._load_platform_novels(platform_b)
        if not novels_a or not novels_b:
            return report
        for na, pa in novels_a:
            for nb, pb in novels_b:
                self._compare_pair(na, nb, platform_a, platform_b, report)
        return report

    def _compare_pair(self, na, nb, platform_a, platform_b, report):
        """比较两部小说。"""
        name_a = na.get("name", "")
        name_b = nb.get("name", "")
        # 1. 书名相似
        if name_a and name_b:
            sim = _title_sim(name_a, name_b)
            if sim >= self.NAME_SIM_THRESHOLD:
                report.add("书名重复", platform_a, platform_b,
                           "《" + name_a + "》≈《" + name_b + "》(相似度" + str(round(sim, 2)) + ")")
        # 2. 章节标题与正文对比
        chs_a = na.get("chapters", [])
        chs_b = nb.get("chapters", [])
        title_hits = 0
        content_hits = 0
        max_content_sim = 0.0
        for ca in chs_a:
            grams_a = _ngrams(ca.get("content", ""))
            for cb in chs_b:
                # 标题
                if ca.get("title") and cb.get("title"):
                    tsim = _title_sim(ca["title"], cb["title"])
                    if tsim >= self.TITLE_SIM_THRESHOLD:
                        title_hits += 1
                # 正文
                grams_b = _ngrams(cb.get("content", ""))
                csim = _jaccard(grams_a, grams_b)
                if csim > max_content_sim:
                    max_content_sim = csim
                if csim >= self.CONTENT_SIM_THRESHOLD:
                    content_hits += 1
        if title_hits > 0:
            report.add("章节标题重复", platform_a, platform_b,
                       "《" + name_a + "》与《" + name_b + "》有 " + str(title_hits) + " 处标题高度相似")
        if content_hits > 0:
            report.add("正文雷同", platform_a, platform_b,
                       "《" + name_a + "》与《" + name_b + "》有 " + str(content_hits) + " 处正文相似度>="
                       + str(self.CONTENT_SIM_THRESHOLD))
        elif max_content_sim >= 0.3:
            # 接近阈值，记录提醒（不计为冲突）
            pass

    # ---------------- 生成避雷参考 ----------------
    def build_avoid_reference(self, platform):
        """为另一平台生成"必须避免雷同"的参考文本。

        提取指定平台已生成小说的书名、章节标题、简介，供另一平台生成时
        注入提示词，主动避免重复。
        """
        novels = self._load_platform_novels(platform)
        if not novels:
            return ""
        parts = ["【已生成平台(" + platform + ")作品，生成时严禁雷同】"]
        for nv, _ in novels:
            parts.append("书名:《" + nv.get("name", "") + "》 简介:" + nv.get("brief", "")[:80])
            chs = nv.get("chapters", [])
            titles = [ch.get("title", "") for ch in chs[:20]]
            if titles:
                parts.append("章节标题: " + " / ".join(titles))
            # 取首章正文摘要作为风格指纹
            if chs and chs[0].get("content"):
                parts.append("首章摘要: " + chs[0]["content"][:120])
        return "\n".join(parts)
