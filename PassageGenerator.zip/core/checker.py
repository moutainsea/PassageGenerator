# -*- coding: utf-8 -*-
"""检查模块：大纲匹配/库匹配/去重/字数/数字逻辑/跨章冲突/技能一致性/反思。

增强（v2）：
  5. 跨章冲突检测：用 LLM 对比相邻章节，发现矛盾自动修复后一章，
     修复后同步更新 libraries 和 novels json。
  6. 技能一致性检查：从文中提取技能/道具/称号，对比前后章是否一致，
     将技能信息写入 character_library.json。
"""
import json
import re
from pathlib import Path

from config import CHAPTER_MIN_WORDS, CHAPTER_MAX_WORDS
from core.llm_client import LLMClient, get_llm
from core.outline_builder import OutlineBuilder
from storage.libraries import Libraries, library_manager


class CheckReport(object):
    """检查报告。"""
    def __init__(self):
        self.passed = True
        self.issues = []
        self.advice = ""
        self.fixes = {}  # 章节序号 -> 修正建议

    def add(self, issue):
        self.issues.append(issue)
        self.passed = False


class NovelChecker(object):
    """小说一致性检查器（增强版）。"""

    def __init__(self, llm=None, libs=None, builder=None):
        self.llm = llm or get_llm()
        self.libs = libs or library_manager
        self.builder = builder or OutlineBuilder(self.llm, self.libs)
        self._novel_path = None  # 由 generator/continuator 注入

    # ---------------- 总检查 ----------------
    def check(self, novel):
        report = CheckReport()
        self._check_outline_match(novel, report)
        self._check_library_match(novel, report)
        self._check_duplicates(novel, report)
        self._check_length(novel, report)
        self._check_numeric_logic(novel, report)
        self._check_skill_first_use(novel, report)
        self._check_character_action_chain(novel, report)
        self._check_fight_transition(novel, report)
        self._check_skill_consistency(novel, report)
        self._check_subplot_consistency(novel, report)
        self._check_cross_chapter_conflicts(novel, report)
        self._reflect(novel, report)
        return report

    # ---------------- 1. 大纲节点匹配 ----------------
    def _check_outline_match(self, novel, report):
        outline = novel.outline
        for ch in novel.chapters:
            sid = outline.chapter_event_map.get(ch.index)
            if not sid:
                report.add("第" + str(ch.index) + "章《" + ch.title + "》在大纲中找不到对应小事件节点")
                continue
            s = self.builder.get_small_event_by_chapter(outline, ch.index)
            if s is None:
                report.add("第" + str(ch.index) + "章对应小事件 " + sid + " 缺失")
                continue
            if ch.small_event_id and ch.small_event_id != sid:
                report.add("第" + str(ch.index) + "章 small_event_id(" + ch.small_event_id + ") 与大纲(" + sid + ") 不一致")
            if ch.outline and ch.outline != s.outline:
                report.add("第" + str(ch.index) + "章大纲与事件库小事件大纲不一致")

    # ---------------- 2. 人物/时间/地点与各库匹配 ----------------
    def _check_library_match(self, novel, report):
        for b, m, s in novel.outline.event_library.iter_small_events():
            if s.protagonist_count < 1:
                report.add("小事件 " + s.id + " 主角人数不足(<1)")
            if s.supporting_count > 3:
                report.add("小事件 " + s.id + " 配角人数超过3")
            for pid in s.state.protagonist_ids:
                if not self.libs.characters.get_protagonist(pid):
                    report.add("小事件 " + s.id + " 主角 " + pid + " 不在主角库中")
            for sid_ in s.state.supporting_ids:
                if not self.libs.characters.get_supporting(sid_):
                    report.add("小事件 " + s.id + " 配角 " + sid_ + " 不在配角库中")
            if s.state.time_id and not self.libs.timeline.get(s.state.time_id):
                report.add("小事件 " + s.id + " 时间 " + s.state.time_id + " 不在时间库中")
            if s.state.location_id and not self.libs.locations.get(s.state.location_id):
                report.add("小事件 " + s.id + " 地点 " + s.state.location_id + " 不在地点库中")

    # ---------------- 3. 重复检查 ----------------
    def _check_duplicates(self, novel, report):
        titles = {}
        for ch in novel.chapters:
            titles.setdefault(ch.title, []).append(ch.index)
        for t, idxs in titles.items():
            if len(idxs) > 1:
                report.add("章节标题重复《" + t + "》：" + str(idxs))
        contents = [(ch.index, ch.content) for ch in novel.chapters if ch.content]
        grams = []
        for idx, text in contents:
            t = "".join(text.split())
            sample = (t[:400] + t[-400:]) if len(t) > 800 else t
            g = set(sample[i:i + 8] for i in range(len(sample) - 7)) if len(sample) >= 8 else set([sample])
            grams.append((idx, len(t), g))
        for i in range(len(grams)):
            li, leni, gi = grams[i]
            for j in range(i + 1, len(grams)):
                lj, lenj, gj = grams[j]
                if leni and lenj and abs(leni - lenj) / float(max(leni, lenj)) > 0.3:
                    continue
                inter = len(gi & gj)
                if inter == 0:
                    continue
                union = len(gi | gj)
                if union == 0:
                    continue
                sim = inter / float(union)
                if sim > 0.6:
                    report.add("第" + str(li) + "章与第" + str(lj) +
                               "章内容相似度过高(" + str(int(sim * 100)) + "%)")

    # ---------------- 4. 字数检查 ----------------
    def _check_length(self, novel, report):
        for ch in novel.chapters:
            if not ch.content:
                report.add("第" + str(ch.index) + "章内容为空")
                continue
            count = len("".join(ch.content.split()))
            if count < CHAPTER_MIN_WORDS:
                report.add("第" + str(ch.index) + "章字数不足(" + str(count) + "<" + str(CHAPTER_MIN_WORDS) + ")")
            elif count > CHAPTER_MAX_WORDS:
                report.add("第" + str(ch.index) + "章字数超限(" + str(count) + ">" + str(CHAPTER_MAX_WORDS) + ")")

    # ---------------- 5. 数字逻辑检查 ----------------
    def _check_numeric_logic(self, novel, report):
        import re
        claims = []
        desc_pat = re.compile(
            r"(速度|力量|防御|攻击|恢复|敏捷|体力|爆发|输出|效率|强度|范围)"
            r"[提升增加加快增强提高至涨了强化上升飞涨暴涨攀升上浮长驱远超原来原本之前]{1,4}"
            r"[了的到至超出过破达到有是]?"
            r"\s*(\d+(?:[.]?\d+)?)\s*([%％倍])", re.I
        )
        for ch in novel.chapters:
            for m in desc_pat.finditer(ch.content):
                capability = m.group(1)
                try:
                    value = float(m.group(2))
                except ValueError:
                    continue
                unit = m.group(3)
                claims.append((ch.index, capability, value, unit, ch.content))
        if len(claims) < 2:
            return
        by_capability = {}
        for ci, cap, val, unit, _ in claims:
            by_capability.setdefault(cap, []).append((ci, val, unit))
        for cap, items in by_capability.items():
            for i in range(len(items) - 1):
                c1, v1, u1 = items[i]
                c2, v2, u2 = items[i + 1]
                if c1 == c2:
                    continue
                if u1 == u2 and v2 < v1:
                    report.add("数字矛盾：第" + str(c1) + "章 " + cap + "提升" + str(v1) + u1
                               + "，第" + str(c2) + "章仅" + str(v2) + u2 + "，疑似数值倒退")
                if u1 == u2 and v2 > v1 * 3:
                    report.add("数字跳变：第" + str(c1) + "章 " + cap + str(v1) + u1
                               + " → 第" + str(c2) + "章 " + str(v2) + u2 + "，增幅过大("
                               + str(int(v2 / v1)) + "倍)，请确认逻辑合理")
        for ci, cap, val, unit, content in claims:
            if cap in ("速度", "敏捷", "效率") and unit == "%":
                for ch in novel.chapters:
                    if ch.index <= ci:
                        continue
                    slow_words = ["缓慢", "迟缓", "吃力", "费劲", "举步维艰"]
                    for sw in slow_words:
                        if sw in ch.content and ch.index - ci <= 2:
                            report.add("速度矛盾：第" + str(ci) + "章声明" + cap + "提升"
                                       + str(val) + "%，但第" + str(ch.index) + "章出现'" + sw
                                       + "'，前后不一致")

    # ---------------- 6. 技能首次使用追踪 ----------------
    def _check_skill_first_use(self, novel, report):
        """追踪每个技能的"首次/第一次"声明，同一技能两次声明即报警。

        根因：LLM逐章生成无全局技能时间线，导致第5章已用扫描探测、第6章却说没
        用过。此检查建立技能首次声明表，发现重复即报警。"""
        import re
        skill_names = re.compile(
            r"(扫描探测|极速配送|透视扫描|防御护盾|声波探测|金属操控|空间折叠|能量护盾|治愈|加速|强化|好运符|夜视|感知|操控金属)"
        )
        first_pat = re.compile(
            r"(首次|第一次|还没用过|从未用过|刚[刚才]?(解锁|激活|获得|学会|觉醒|用了)).{0,60}"
        )
        first_record = {}
        for ch in novel.chapters:
            content = ch.content
            for sk_m in skill_names.finditer(content):
                sk_name = sk_m.group(1)
                before = content[max(0, sk_m.start() - 80):sk_m.start()]
                if first_pat.search(before):
                    if sk_name in first_record:
                        report.add("技能矛盾：" + sk_name + " 在第" + str(first_record[sk_name][0]) +
                                   "章已声称首次使用/解锁，第" + str(ch.index) + "章再次声称首次")
                    else:
                        first_record[sk_name] = (ch.index, before[-50:])

    # ---------------- 7. 角色行为链一致性 ----------------
    def _check_character_action_chain(self, novel, report):
        """检测相邻3章内对主角的同类型互动是否由不同角色执行。

        根因：功能相似的角色在LLM生成时易混淆（如赵磊/老张都是"拦下主角的执法者"）。
        角色名从 character_library.json 动态读取，避免硬编码遗漏。
        """
        import re
        # 从人物库动态收集所有角色名（非空且有意义的名字）
        char_names = []
        for c in self.libs.characters.all_characters():
            name = c.name or ""
            # 过滤掉纯英文 id 式名字（如 male_lead/customer1）
            if not name or re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", name):
                continue
            if len(name) >= 2:
                char_names.append(name)
        if not char_names:
            return
        # 按长度降序，避免短名先匹配（如"零"会干扰"暗网首领零"）
        char_names.sort(key=len, reverse=True)
        name_alt = "|".join(re.escape(n) for n in char_names)
        interact_pat = re.compile(
            r"(" + name_alt + r")"
            r".{0,25}(拦住|拦下|挡住|叫住|拉住|拍.{0,3}肩膀|按在地|问.{0,3}陈默|"
            r"拦|截住|堵住|追上|逼退|围住)"
        )
        records = []
        for ch in novel.chapters:
            for m in interact_pat.finditer(ch.content):
                records.append((ch.index, m.group(1), m.group(2), m.group(0)[:60]))
        for i in range(len(records) - 1):
            c1, n1, a1, _ = records[i]
            c2, n2, a2, _ = records[i + 1]
            if n1 != n2 and a1 == a2 and c2 - c1 <= 3:
                report.add("角色混淆：第" + str(c1) + "章「" + n1 + "」" + a1 +
                           " → 第" + str(c2) + "章「" + n2 + "」同行为，请确认一致性")

    # ---------------- 8. 打斗场景过渡检测 ----------------
    def _check_fight_transition(self, novel, report):
        """检测打斗/冲突开始信号后，是否在1000字内有明确收束。

        根因：LLM倾向描述行动前后，中间动作细节跳跃（如老张vs光头对峙→下一瞬间
        光头已挪到门口，省略缠斗过程）。"""
        import re
        begin_pat = re.compile(r"(警察.{0,5}不许动|一[个记声].{0,5}(暴喝|厉喝|低喝|怒喝)" +
                               r"|猛地.{0,5}(冲了出去|扑|拔|抽|挥|踹|砸|抡))")
        settle_pat = re.compile(r"(制服|按倒|拷上|倒下|压.{0,3}在地|缴了|踹翻|击退|打退|摔出|弹飞|瘫坐|搞定)")
        for ch in novel.chapters:
            content = ch.content
            begins = list(begin_pat.finditer(content))
            if not begins:
                continue
            last_begin = begins[-1].start()
            tail = content[last_begin:]
            if not settle_pat.search(tail[:1000]):
                report.add("打斗跳跃：第" + str(ch.index) + "章有打斗开始信号('" +
                           begins[-1].group(0)[:30] + "')但后1000字内无收束，可能缺失过程")

    # ---------------- 9. 跨章节冲突检查 ----------------
    def _check_cross_chapter_conflicts(self, novel, report):
        """用 LLM 逐对检测相邻章节的矛盾，发现后自动修复后一章，
        并更新 libraries 和 novels json。"""
        chapters = novel.chapters
        if len(chapters) < 2:
            return
        # 最多检查最后 30 章（控制耗时）
        recent = chapters[-30:] if len(chapters) > 30 else chapters
        for i in range(len(recent) - 1):
            prev_ch = recent[i]
            curr_ch = recent[i + 1]
            system = (
                "你是严谨的网文逻辑审查员。请严格对比前后两章内容，检查是否存在："
                "矛盾、冲突、不合理、不通顺的地方。例如：前一章角色受伤但后一章立即痊愈、"
                "前一章某物品丢失后一章却出现、时间线跳跃不合理、人物关系前后矛盾、"
                "地点描述不一致等。返回 JSON："
                "{\"has_conflict\": bool, \"conflicts\": [字符串描述], \"fix_needed\": bool}。"
            )
            user = (
                "前一章（第" + str(prev_ch.index) + "章《" + prev_ch.title + "》）:\n"
                + prev_ch.content[:800] + "\n\n---\n\n"
                "后一章（第" + str(curr_ch.index) + "章《" + curr_ch.title + "》）:\n"
                + curr_ch.content[:800]
            )
            data = self.llm.chat_json(system, user)
            if data.get("has_conflict") and data.get("fix_needed"):
                conflicts = data.get("conflicts", [])
                conflict_str = "；".join(str(c) for c in conflicts[:3])
                report.add("跨章冲突[第" + str(prev_ch.index) + "→" + str(curr_ch.index) + "]: " + conflict_str)
                # 自动修复后一章
                fixed = self._fix_chapter_for_conflict(curr_ch, prev_ch, conflicts)
                if fixed:
                    curr_ch.content = fixed
                    self._update_libraries_from_chapter(curr_ch, novel)
                    self._save_novel_json(novel)
                    report.add("  [已修复] 第" + str(curr_ch.index) + "章已根据冲突修正")

    def _fix_chapter_for_conflict(self, chapter, prev_chapter, conflicts):
        """根据检测到的冲突，用 LLM 重写后一章使其与前章一致。"""
        system = (
            "你是网文写手。前一章与本章存在逻辑冲突，请基于前一章内容修正本章，"
            "消除所有矛盾，使前后一致、逻辑通顺。保持原剧情方向、人物性格和字数。"
            "只输出修正后的完整正文。"
        )
        conflict_desc = "；".join(str(c) for c in conflicts[:5])
        user = (
            "前一章（第" + str(prev_chapter.index) + "章《" + prev_chapter.title + "》）摘要:\n"
            + prev_chapter.content[:500] + "\n\n"
            "当前章（第" + str(chapter.index) + "章《" + chapter.title + "》）:\n"
            + chapter.content + "\n\n"
            "检测到的冲突: " + conflict_desc + "\n\n"
            "请输出修正后的完整正文，字数 " + str(CHAPTER_MIN_WORDS) + "-" + str(CHAPTER_MAX_WORDS) + " 字。"
        )
        result = self.llm.chat(system, user)
        if result and len("".join(result.split())) > CHAPTER_MIN_WORDS // 2:
            return result
        return None

    def _update_libraries_from_chapter(self, chapter, novel):
        """根据章节内容更新人物/地点/时间库。"""
        # 找到对应小事件
        sid = novel.outline.chapter_event_map.get(chapter.index)
        if not sid:
            return
        s = self.builder.get_small_event_by_chapter(novel.outline, chapter.index)
        if s is None:
            return
        # 更新主角
        for pid in s.state.protagonist_ids:
            c = self.libs.characters.get_protagonist(pid)
            if not c:
                from models.character import Character, CharacterRole
                c = Character(id=pid, name=pid, role=CharacterRole.PROTAGONIST)
                self.libs.characters.add_protagonist(c)
        # 更新配角
        for sid_ in s.state.supporting_ids:
            c = self.libs.characters.get_supporting(sid_)
            if not c:
                from models.character import Character, CharacterRole
                c = Character(id=sid_, name=sid_, role=CharacterRole.SUPPORTING,
                              last_appear_time=s.state.time_id,
                              last_appear_location=s.state.location_id)
                self.libs.characters.add_supporting(c)
        self.libs.save()

    # ---------------- 7. 技能一致性检查 ----------------
    def _check_skill_consistency(self, novel, report):
        """从各章节提取技能/道具/称号，对比前后一致性，
        将新发现的写入 character_library.json，发现不一致则修复后一章。"""
        import re
        # 从正文提取技能/道具/称号声明
        skill_pat = re.compile(
            r"(技能|道具|能力|天赋|异能|功法|武器|法宝|称号|头衔|徽章|权柄)[：:：\s]*"
            r"[\"「『]([^\"」』]{2,20})[\"」』]"
        )
        skill2_pat = re.compile(
            r"(获得|解锁|激活|开启|领悟|觉醒|得到|获取|习得|掌握|赐予|赋予)"
            r"[了的]*[：:：\s]*[\"「『]?([^\"」』，。,\.\n]{2,20})[\"」』]?"
            r"[\s　]*的?(技能|能力|道具|天赋|功法|异能)"
        )
        # 收集每章的技能声明
        chapter_skills = {}  # {chapter_index: [skill_name]}
        for ch in novel.chapters:
            found = set()
            for m in skill_pat.finditer(ch.content):
                found.add(m.group(2))
            for m in skill2_pat.finditer(ch.content):
                found.add(m.group(2))
            chapter_skills[ch.index] = found

        if not chapter_skills:
            return

        # 按章节顺序检测不一致
        all_known = set()
        for ch in novel.chapters:
            new_skills = chapter_skills.get(ch.index, set())
            for sk in new_skills:
                if sk in all_known:
                    continue
                all_known.add(sk)
            # 发现新技能，写入对应主角的 skills 列表
            self._add_skills_to_character_library(ch, new_skills)

        # 检查是否有已出现技能在后文消失又重现（可选）
        for i in range(1, len(novel.chapters)):
            prev_skills = chapter_skills.get(novel.chapters[i-1].index, set())
            curr_skills = chapter_skills.get(novel.chapters[i].index, set())
            if not prev_skills or not curr_skills:
                continue
            # 前一章有大量技能，后一章没提 → 不一定是问题，忽略
            # 但前一章明确"获得"了某项技能后一章却说"没有" → 检测矛盾
            deny_pat = re.compile(r"(没有|从未|不会|丧失了|失去了|消失了|没了)[\s\S]{0,20}(技能|能力|道具|天赋)")
            for m in deny_pat.finditer(novel.chapters[i].content):
                denied_context = m.group(0)
                for sk in prev_skills:
                    if sk in denied_context or any(sk_ch in denied_context for sk_ch in sk[:2]):
                        report.add(
                            "技能矛盾：第" + str(novel.chapters[i-1].index) + "章出现'" + sk
                            + "'，第" + str(novel.chapters[i].index) + "章暗示不具备此技能"
                        )

        # 写回 character_library
        self.libs.save()

    def _add_skills_to_character_library(self, chapter, skills):
        """将新发现的技能/道具/称号追加到主角/配角的库记录中。

        使用规范化方法 add_skill/add_item/add_title，统一存储为
        {name, chapter, effect} dict 格式，避免 str/dict 混合。
        """
        for pid in ["male_lead"]:  # 默认追加到 male_lead
            c = self.libs.characters.get_protagonist(pid)
            if not c:
                continue
            for sk in skills:
                sk = (sk or "").strip()
                if not sk or len(sk) < 2:
                    continue
                # 识别道具类
                if any(kw in sk for kw in ["刀", "剑", "枪", "棍", "棒", "斧", "锤", "鞭", "弓", "弩", "盾", "甲", "盔", "鼎", "炉", "符", "丹", "印", "令", "牌", "石", "珠", "玉", "环", "塔", "镜", "扇", "尺"]):
                    c.add_item(sk, chapter=chapter.index, effect="")
                # 识别称号类
                elif any(kw in sk for kw in ["帝", "皇", "王", "神", "仙", "圣", "尊", "祖", "主", "师", "灵", "魔", "龙", "凤"]):
                    c.add_title(sk, chapter=chapter.index, effect="")
                # 其余按技能处理
                else:
                    c.add_skill(sk, chapter=chapter.index, effect="")

    # ---------------- 10. 分线一致性检查 ----------------
    def _check_subplot_consistency(self, novel, report):
        """检查分线交替是否合理。

        检查项：
        1. 分线结构是否存在（至少2条）
        2. 所有章节是否都已分配到分线
        3. 分线切换是否过于频繁（单线连续不足2章）或过于稀疏（单线连续超过6章）
        4. 分线切换点是否有衔接（用 LLM 检查开头过渡是否自然）
        """
        subplots = novel.outline.subplots
        if not subplots:
            report.add("分线结构缺失：outline.subplots 为空，不符合分线叙事制要求")
            return
        if len(subplots) < 2:
            report.add("分线数不足：仅" + str(len(subplots)) + "条分线，须至少2条交替推进")
            return

        # 检查章节覆盖
        all_chapter_indices = set()
        for sp in subplots:
            sp_dict = sp.to_dict() if hasattr(sp, "to_dict") else sp
            all_chapter_indices.update(sp_dict.get("chapter_indices", []))
        for ch in novel.chapters:
            if ch.index not in all_chapter_indices:
                report.add("第" + str(ch.index) + "章未分配到任何分线")

        # 检查分线交替规律
        # 构建章节->分线 映射
        ch_to_sp = {}
        for sp in subplots:
            sp_dict = sp.to_dict() if hasattr(sp, "to_dict") else sp
            for ci in sp_dict.get("chapter_indices", []):
                ch_to_sp[ci] = sp_dict.get("name", "")

        sorted_chs = sorted(ch_to_sp.keys())
        if len(sorted_chs) < 2:
            return

        # 检查连续同线章节数
        current_line = ch_to_sp[sorted_chs[0]]
        consecutive = 1
        for i in range(1, len(sorted_chs)):
            ci = sorted_chs[i]
            if ch_to_sp[ci] == current_line:
                consecutive += 1
                if consecutive > 6:
                    report.add(
                        "分线单一过长：" + current_line + "连续" + str(consecutive) +
                        "章未切换，读者易疲惫（第" + str(sorted_chs[i - consecutive + 1]) +
                        "~" + str(ci) + "章）"
                    )
            else:
                if consecutive < 2 and i > 1:
                    report.add(
                        "分线切换过频：第" + str(ci) + "章从「" + current_line +
                        "」切换到「" + ch_to_sp[ci] + "」，前一线仅" + str(consecutive) + "章"
                    )
                current_line = ch_to_sp[ci]
                consecutive = 1

        # 检查分线切换点的衔接（抽样检查，避免过多 LLM 调用）
        switch_points = []
        for i in range(1, len(sorted_chs)):
            ci = sorted_chs[i]
            prev_ci = sorted_chs[i - 1]
            if ch_to_sp[ci] != ch_to_sp[prev_ci]:
                switch_points.append((prev_ci, ci, ch_to_sp[prev_ci], ch_to_sp[ci]))

        # 最多检查前3个切换点
        for prev_ci, ci, prev_line, curr_line in switch_points[:3]:
            prev_ch = None
            curr_ch = None
            for ch in novel.chapters:
                if ch.index == prev_ci:
                    prev_ch = ch
                if ch.index == ci:
                    curr_ch = ch
            if not prev_ch or not curr_ch:
                continue
            # 用 LLM 检查切换衔接
            system = (
                "你是网文逻辑审查员。请检查分线切换处的前后章节衔接是否自然合理。"
                "前一章属于「" + prev_line + "」，后一章属于「" + curr_line + "」。"
                "返回 JSON：{\"natural\": bool, \"issue\": \"问题描述(若无则空)\"}。"
            )
            user = (
                "前一章（第" + str(prev_ci) + "章《" + prev_ch.title + "》）结尾:\n"
                + prev_ch.content[-300:] + "\n\n"
                "后一章（第" + str(ci) + "章《" + curr_ch.title + "》）开头:\n"
                + curr_ch.content[:300]
            )
            data = self.llm.chat_json(system, user)
            if not data.get("natural", True):
                issue = data.get("issue", "")
                report.add(
                    "分线切换衔接问题[第" + str(prev_ci) + "→" + str(ci) + "章 " +
                    prev_line + "→" + curr_line + "]: " + str(issue)
                )

    # ---------------- 共享保存 ----------------
    def _save_novel_json(self, novel):
        """保存 novel json，由 caller 设置 _novel_path。"""
        if not self._novel_path:
            return
        self._novel_path.write_text(
            json.dumps(novel.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    # ---------------- 6（原）. 反思 ----------------
    def _reflect(self, novel, report):
        chapters = novel.chapters
        if not chapters:
            return
        system = (
            "你是网文主编。请对给出的章节进行反思审查，重点检查："
            "是否有错漏、是否有不通顺或太AI风格的表达、前后章节(前1后1)衔接是否合理。"
            "返回 JSON：{\"pass\": bool, \"issues\": [字符串], \"advice\": \"\"}。"
        )
        lines = []
        n = len(chapters)
        if n <= 12:
            sample = chapters
        else:
            step = max(1, n // 10)
            idxs = sorted(set([0, n - 1] + list(range(0, n, step))))[:12]
            sample = [chapters[i] for i in idxs]
        for ch in sample:
            lines.append(
                "第" + str(ch.index) + "章《" + ch.title + "》｜大纲：" + ch.outline +
                "\n正文摘要：" + ch.content[:300]
            )
        user = "小说简介：" + novel.brief + "（共" + str(n) + "章，反思抽样" + str(len(sample)) + "章）\n\n" + "\n\n".join(lines)
        data = self.llm.chat_json(system, user)
        if not data.get("pass", True):
            for iss in data.get("issues", []):
                report.add("[反思] " + str(iss))
        if data.get("advice"):
            report.advice = data["advice"]

    # ---------------- 修正建议 ----------------
    def suggest_fix(self, chapter, issue):
        system = (
            "你是网文写手。请根据指出的问题重写章节正文，"
            "保持原剧情与人物，字数 2200-3200 字，只输出正文。"
        )
        user = (
            "章节标题：" + chapter.title + "\n大纲：" + chapter.outline + "\n"
            "当前正文：\n" + chapter.content + "\n\n需要修正的问题：" + issue + "\n"
            "请输出修正后的完整正文。"
        )
        return self.llm.chat(system, user)
