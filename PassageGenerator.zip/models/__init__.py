# -*- coding: utf-8 -*-
"""数据模型层。"""
from .character import Character, CharacterRole
from .event import (
    BigEvent,
    MiddleEvent,
    SmallEvent,
    EventState,
    EventLibrary,
)
from .location import Location, LocationLibrary
from .timeline import TimePoint, TimelineLibrary
from .novel import Novel, Chapter, NovelOutline

__all__ = [
    "Character", "CharacterRole",
    "BigEvent", "MiddleEvent", "SmallEvent", "EventState", "EventLibrary",
    "Location", "LocationLibrary",
    "TimePoint", "TimelineLibrary",
    "Novel", "Chapter", "NovelOutline",
]
