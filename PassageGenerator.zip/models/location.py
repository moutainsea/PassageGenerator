# -*- coding: utf-8 -*-
"""地点模型：地点库文件，记录可复用的地点信息。"""


class Location(object):
    def __init__(self, id, name, type="", description="", features=None,
                 parent_id="", reuse_count=0, remark=""):
        self.id = id
        self.name = name
        self.type = type                # 地点类型，如 城市/山林/秘境/宗门
        self.description = description  # 地点描述
        self.features = features if features is not None else []  # 特征
        self.parent_id = parent_id      # 所属上级地点
        self.reuse_count = reuse_count  # 复用次数
        self.remark = remark

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "type": self.type,
            "description": self.description,
            "features": list(self.features),
            "parent_id": self.parent_id,
            "reuse_count": self.reuse_count,
            "remark": self.remark,
        }

    @classmethod
    def from_dict(cls, data):
        return cls(**dict(data))


class LocationLibrary(object):
    def __init__(self, locations=None):
        self.locations = locations if locations is not None else {}

    def to_dict(self):
        return {
            "locations": {k: v.to_dict() for k, v in self.locations.items()}
        }

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        locs = {
            k: Location.from_dict(v)
            for k, v in data.get("locations", {}).items()
        }
        return cls(locations=locs)

    def add(self, loc):
        self.locations[loc.id] = loc

    def get(self, loc_id):
        return self.locations.get(loc_id)
