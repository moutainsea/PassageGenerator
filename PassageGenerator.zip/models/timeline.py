# -*- coding: utf-8 -*-
"""时间模型：时间库文件，记录可复用的时间节点信息。"""


class TimePoint(object):
    def __init__(self, id, name, chronology="", description="", order=0,
                 reuse_count=0, remark=""):
        self.id = id
        self.name = name                     # 时间名称，如 "开篇·初春"
        self.chronology = chronology         # 纪年/时间线位置
        self.description = description       # 时间描述
        self.order = order                   # 在时间线上的顺序
        self.reuse_count = reuse_count
        self.remark = remark

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "chronology": self.chronology,
            "description": self.description,
            "order": self.order,
            "reuse_count": self.reuse_count,
            "remark": self.remark,
        }

    @classmethod
    def from_dict(cls, data):
        return cls(**dict(data))


class TimelineLibrary(object):
    def __init__(self, points=None):
        self.points = points if points is not None else {}

    def to_dict(self):
        return {
            "points": {k: v.to_dict() for k, v in self.points.items()}
        }

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        pts = {
            k: TimePoint.from_dict(v)
            for k, v in data.get("points", {}).items()
        }
        return cls(points=pts)

    def add(self, tp):
        self.points[tp.id] = tp

    def get(self, tp_id):
        return self.points.get(tp_id)
