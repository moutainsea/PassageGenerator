# -*- coding: utf-8 -*-
"""事件模型：事件线（大事件 → 中事件 → 小事件）。

小事件结构：事件影响 + 事件背景 + 主角人数 + 配角人数 + 人物形象
           + 人物行为 + 所处时间 + 所在地表状态表。
小事件的转移即状态表的转移。
"""


class EventState(object):
    """小事件的状态表：人物/时间/地点等可流转的状态。

    状态表的转移 = 小事件之间的转移依据。
    """
    def __init__(self, time_id="", location_id="", protagonist_ids=None,
                 supporting_ids=None, character_states=None,
                 location_status="", extra=None):
        self.time_id = time_id                          # 所处时间节点 id
        self.location_id = location_id                  # 所在地点 id
        self.protagonist_ids = protagonist_ids if protagonist_ids is not None else []
        self.supporting_ids = supporting_ids if supporting_ids is not None else []
        self.character_states = character_states if character_states is not None else {}
        self.location_status = location_status          # 地点当前状态描述
        self.extra = extra if extra is not None else {}

    def to_dict(self):
        return {
            "time_id": self.time_id,
            "location_id": self.location_id,
            "protagonist_ids": list(self.protagonist_ids),
            "supporting_ids": list(self.supporting_ids),
            "character_states": dict(self.character_states),
            "location_status": self.location_status,
            "extra": dict(self.extra),
        }

    @classmethod
    def from_dict(cls, data):
        return cls(**dict(data))


class SmallEvent(object):
    """小事件：章节扩写的最小单元。"""
    def __init__(self, id, title, impact="", background="",
                 protagonist_count=1, supporting_count=0,
                 character_ids=None, character_image="", behavior="",
                 time_desc="", location_desc="", state=None,
                 outline="", chapter_index=None):
        self.id = id
        self.title = title                              # 章节名称候选
        self.impact = impact                            # 事件影响
        self.background = background                    # 事件背景
        self.protagonist_count = protagonist_count      # 主角人数 >=1
        self.supporting_count = supporting_count        # 配角人数 0-3
        self.character_ids = character_ids if character_ids is not None else []
        self.character_image = character_image          # 人物形象描述
        self.behavior = behavior                        # 人物行为
        self.time_desc = time_desc                      # 所处时间描述
        self.location_desc = location_desc              # 所在地点描述
        self.state = state if state is not None else EventState()  # 状态表
        self.outline = outline                          # 该小事件对应章节的大纲要点
        self.chapter_index = chapter_index              # 对应章节序号

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "impact": self.impact,
            "background": self.background,
            "protagonist_count": self.protagonist_count,
            "supporting_count": self.supporting_count,
            "character_ids": list(self.character_ids),
            "character_image": self.character_image,
            "behavior": self.behavior,
            "time_desc": self.time_desc,
            "location_desc": self.location_desc,
            "state": self.state.to_dict(),
            "outline": self.outline,
            "chapter_index": self.chapter_index,
        }

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        if "state" in data and isinstance(data["state"], dict):
            data["state"] = EventState.from_dict(data["state"])
        return cls(**data)


class MiddleEvent(object):
    """中事件：由若干小事件组成。"""
    def __init__(self, id, title, summary="", small_events=None):
        self.id = id
        self.title = title
        self.summary = summary
        self.small_events = small_events if small_events is not None else []

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "summary": self.summary,
            "small_events": [e.to_dict() for e in self.small_events],
        }

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        data["small_events"] = [
            SmallEvent.from_dict(e) for e in data.get("small_events", [])
        ]
        return cls(**data)


class BigEvent(object):
    """大事件：由若干中事件组成。事件线的顶层。"""
    def __init__(self, id, title, summary="", middle_events=None):
        self.id = id
        self.title = title
        self.summary = summary
        self.middle_events = middle_events if middle_events is not None else []

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "summary": self.summary,
            "middle_events": [m.to_dict() for m in self.middle_events],
        }

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        data["middle_events"] = [
            MiddleEvent.from_dict(m) for m in data.get("middle_events", [])
        ]
        return cls(**data)


class EventLibrary(object):
    """事件库文件：独立的整条事件线。"""
    def __init__(self, big_events=None):
        self.big_events = big_events if big_events is not None else []

    def to_dict(self):
        return {"big_events": [b.to_dict() for b in self.big_events]}

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        data["big_events"] = [
            BigEvent.from_dict(b) for b in data.get("big_events", [])
        ]
        return cls(**data)

    def iter_small_events(self):
        """扁平遍历所有小事件。"""
        for b in self.big_events:
            for m in b.middle_events:
                for s in m.small_events:
                    yield b, m, s
