# -*- coding: utf-8 -*-
"""小说模型：小说总体结构（名称/简介/分类/大纲/章节）。"""
from .event import EventLibrary


class Subplot(object):
    """分线：小说的多线叙事结构。

    每个分线描述一条并行的故事线索，各分线在完成一个小阶段后交替切换，
    避免读者疲惫。分线之间的切换须保证衔接和前后情节合理通顺。
    """
    def __init__(self, id="", name="", description="", chapter_indices=None, stages=None):
        self.id = id                                  # 分线标识（如 career_line）
        self.name = name                              # 分线名称（如 餐饮事业线）
        self.description = description                # 分线描述
        self.chapter_indices = chapter_indices or []  # 属于该分线的章节序号列表
        # 阶段列表：[{"name":"阶段名","chapters":[1,2],"summary":"阶段叙述"}]
        self.stages = stages or []

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "chapter_indices": list(self.chapter_indices),
            "stages": list(self.stages),
        }

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        return cls(**data)


class Chapter(object):
    """章节：章节名称 + 章节内容，对应一个小事件的扩写。"""
    def __init__(self, index, title, small_event_id="", outline="", content=""):
        self.index = index                # 章节序号，从1开始
        self.title = title                # 章节名称
        self.small_event_id = small_event_id  # 对应小事件 id
        self.outline = outline            # 本章大纲要点
        self.content = content            # 章节内容

    def to_dict(self):
        return {
            "index": self.index,
            "title": self.title,
            "small_event_id": self.small_event_id,
            "outline": self.outline,
            "content": self.content,
        }

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        # 只保留 __init__ 支持的参数，忽略 word_count 等额外字段
        valid_keys = {"index", "title", "small_event_id", "outline", "content"}
        return cls(**{k: v for k, v in data.items() if k in valid_keys})


class NovelOutline(object):
    """小说大纲：以事件线为主，辅以分线结构。"""
    def __init__(self, event_library=None, chapter_event_map=None, subplots=None):
        self.event_library = event_library if event_library is not None else EventLibrary()
        # 章节与小事件的映射（章节序号 -> 小事件 id）
        self.chapter_event_map = chapter_event_map if chapter_event_map is not None else {}
        # 分线列表：描述小说的多线叙事结构，各分线交替推进
        self.subplots = subplots if subplots is not None else []

    def to_dict(self):
        return {
            "event_library": self.event_library.to_dict(),
            "chapter_event_map": self.chapter_event_map,
            "subplots": [s.to_dict() if hasattr(s, "to_dict") else dict(s)
                         for s in self.subplots],
        }

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        data["event_library"] = EventLibrary.from_dict(
            data.get("event_library", {})
        )
        raw_subplots = data.get("subplots", [])
        data["subplots"] = [
            Subplot.from_dict(s) if isinstance(s, dict) else s
            for s in raw_subplots
        ]
        return cls(**data)


class Novel(object):
    """小说总结构。"""
    def __init__(self, name, brief="", category="", tags=None,
                 outline=None, chapters=None):
        self.name = name                                  # 小说名称（<=10字）
        self.brief = brief                                # 小说简介（<=100字）
        self.category = category                          # 小说分类
        self.tags = tags if tags is not None else []      # 类别标签
        self.outline = outline if outline is not None else NovelOutline()
        self.chapters = chapters if chapters is not None else []

    def to_dict(self):
        return {
            "name": self.name,
            "brief": self.brief,
            "category": self.category,
            "tags": list(self.tags),
            "outline": self.outline.to_dict(),
            "chapters": [c.to_dict() for c in self.chapters],
        }

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        data["outline"] = NovelOutline.from_dict(data.get("outline", {}))
        data["chapters"] = [
            Chapter.from_dict(c) for c in data.get("chapters", [])
        ]
        return cls(**data)
