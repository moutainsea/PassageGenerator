# -*- coding: utf-8 -*-
"""人物模型：主角形象库与配角形象库共用此结构。

skills/items/titles 在 JSON 中统一存储为 dict 对象数组：
  [{"name": "扫描探测", "chapter": 5, "effect": "对周围区域进行扫描..."}]
历史数据可能混有纯字符串，本模块提供兼容方法统一处理。
"""
from enum import Enum


def _extract_attr(item, key):
    """从 skills/items/titles 的元素中提取字段，兼容 dict 与 str。"""
    if isinstance(item, dict):
        return item.get(key, "") or ""
    if key == "name":
        return str(item) if item else ""
    return ""


def _normalize_attr(item):
    """将单个 skill/item/title 规范化为 dict {name, chapter, effect}。"""
    if isinstance(item, dict):
        return {
            "name": item.get("name", "") or "",
            "chapter": item.get("chapter", 0) or 0,
            "effect": item.get("effect", "") or "",
        }
    return {"name": str(item) if item else "", "chapter": 0, "effect": ""}


class CharacterRole(str, Enum):
    """人物类型。"""
    PROTAGONIST = "protagonist"   # 主角（男一/女一/男二/女二…）
    SUPPORTING = "supporting"     # 配角


class Character(object):
    """人物形象。

    主角在各大/中事件下的信息以 per_event_info 记录，
    配角则记录可复用的背景与上次出现时间等。
    """
    def __init__(self, id, name, role=CharacterRole.PROTAGONIST, role_label="",
                 age=0, gender="", personality="", background="",
                 skills=None, items=None, titles=None, experience="",
                 per_event_info=None, last_appear_time="",
                 last_appear_location="", reuse_hint="", remark=""):
        self.id = id                                  # 唯一标识，如 "male_lead"
        self.name = name                              # 姓名
        if isinstance(role, str):
            role = CharacterRole(role)
        self.role = role
        self.role_label = role_label                  # 角色定位，如 男一/女一/男二
        self.age = age
        self.gender = gender
        self.personality = personality                # 性格
        self.background = background                  # 背景
        self.skills = skills if skills is not None else []      # 技能
        self.items = items if items is not None else []         # 道具
        self.titles = titles if titles is not None else []      # 称号
        self.experience = experience                  # 经历
        # 主角：各事件下的状态信息；配角：可复用情景说明
        self.per_event_info = per_event_info if per_event_info is not None else {}
        # 配角复用相关
        self.last_appear_time = last_appear_time      # 上次出现时间（时间线节点 id）
        self.last_appear_location = last_appear_location  # 上次出现地点
        self.reuse_hint = reuse_hint                  # 复用场景提示，如 故地重逢/碰巧遇到/共同目标
        self.remark = remark

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "role": self.role.value,
            "role_label": self.role_label,
            "age": self.age,
            "gender": self.gender,
            "personality": self.personality,
            "background": self.background,
            "skills": list(self.skills),
            "items": list(self.items),
            "titles": list(self.titles),
            "experience": self.experience,
            "per_event_info": dict(self.per_event_info),
            "last_appear_time": self.last_appear_time,
            "last_appear_location": self.last_appear_location,
            "reuse_hint": self.reuse_hint,
            "remark": self.remark,
        }

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        if isinstance(data.get("role"), str):
            data["role"] = CharacterRole(data["role"])
        return cls(**data)

    # ---------------- skills/items/titles 规范化访问 ----------------
    @staticmethod
    def _attr_name(item):
        return _extract_attr(item, "name")

    @staticmethod
    def _attr_effect(item):
        return _extract_attr(item, "effect")

    def skill_names(self):
        """返回所有技能名列表（纯字符串）。"""
        return [self._attr_name(s) for s in self.skills if self._attr_name(s)]

    def item_names(self):
        """返回所有道具名列表（纯字符串）。"""
        return [self._attr_name(s) for s in self.items if self._attr_name(s)]

    def title_names(self):
        """返回所有称号名列表（纯字符串）。"""
        return [self._attr_name(s) for s in self.titles if self._attr_name(s)]

    def skill_details(self):
        """返回技能详情字符串列表，格式: 名字（效果）。"""
        out = []
        for s in self.skills:
            name = self._attr_name(s)
            if not name:
                continue
            eff = self._attr_effect(s)
            out.append(name + ("（" + eff + "）" if eff else ""))
        return out

    def item_details(self):
        """返回道具详情字符串列表，格式: 名字（效果）。"""
        out = []
        for s in self.items:
            name = self._attr_name(s)
            if not name:
                continue
            eff = self._attr_effect(s)
            out.append(name + ("（" + eff + "）" if eff else ""))
        return out

    def title_details(self):
        """返回称号详情字符串列表，格式: 名字（效果）。"""
        out = []
        for s in self.titles:
            name = self._attr_name(s)
            if not name:
                continue
            eff = self._attr_effect(s)
            out.append(name + ("（" + eff + "）" if eff else ""))
        return out

    def add_skill(self, name, chapter=0, effect=""):
        """规范化追加技能，避免重复。"""
        name = (name or "").strip()
        if not name:
            return
        existing = set(self.skill_names())
        if name in existing:
            return
        self.skills.append({"name": name, "chapter": chapter, "effect": effect})

    def add_item(self, name, chapter=0, effect=""):
        """规范化追加道具，避免重复。"""
        name = (name or "").strip()
        if not name:
            return
        existing = set(self.item_names())
        if name in existing:
            return
        self.items.append({"name": name, "chapter": chapter, "effect": effect})

    def add_title(self, name, chapter=0, effect=""):
        """规范化追加称号，避免重复。"""
        name = (name or "").strip()
        if not name:
            return
        existing = set(self.title_names())
        if name in existing:
            return
        self.titles.append({"name": name, "chapter": chapter, "effect": effect})

    def attr_summary(self):
        """返回该角色全部技能/道具/称号的可读摘要，供 LLM 参考。"""
        parts = []
        if self.skill_details():
            parts.append("技能: " + "; ".join(self.skill_details()))
        if self.item_details():
            parts.append("道具: " + "; ".join(self.item_details()))
        if self.title_details():
            parts.append("称号: " + "; ".join(self.title_details()))
        return "\n".join(parts)
