# -*- coding: utf-8 -*-
"""调研结果存储：将最热小说信息存为 json。

文件命名规则（来自架构）：
  - 按时间查询：时间戳 + hot20  ->  {timestamp}_hot20.json
  - 按类别标签：时间戳 + 类别标签 -> {timestamp}_{tag}.json
"""
import json
from datetime import datetime
from pathlib import Path

from config import RESEARCH_DIR


class NovelResearchItem(object):
    """单部调研小说的信息。"""
    def __init__(self, name="", brief="", category="", tags=None,
                 chapter_names=None, outline="", heat=0, source=""):
        self.name = name                         # 小说名称
        self.brief = brief                        # 小说简介
        self.category = category                  # 小说分类
        self.tags = tags if tags is not None else []
        self.chapter_names = chapter_names if chapter_names is not None else []
        self.outline = outline                    # 详细/超详细大纲
        self.heat = heat                          # 热度
        self.source = source                      # 来源

    def to_dict(self):
        return {
            "name": self.name,
            "brief": self.brief,
            "category": self.category,
            "tags": list(self.tags),
            "chapter_names": list(self.chapter_names),
            "outline": self.outline,
            "heat": self.heat,
            "source": self.source,
        }

    @classmethod
    def from_dict(cls, data):
        return cls(**dict(data))


class ResearchResult(object):
    """一次调研的结果集合。"""
    def __init__(self, query_type, timestamp="", items=None, remark=""):
        self.query_type = query_type            # "hot20" 或 类别标签
        self.timestamp = timestamp
        self.items = items if items is not None else []
        self.remark = remark

    def to_dict(self):
        return {
            "query_type": self.query_type,
            "timestamp": self.timestamp,
            "items": [i.to_dict() for i in self.items],
            "remark": self.remark,
        }

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        data["items"] = [
            NovelResearchItem.from_dict(i) for i in data.get("items", [])
        ]
        return cls(**data)


class ResearchStore(object):
    """调研结果文件读写。"""

    def __init__(self, base_dir=None):
        self.base_dir = base_dir or RESEARCH_DIR
        self.base_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _now_ts():
        return datetime.now().strftime("%Y%m%d_%H%M%S")

    def save(self, result):
        """按架构命名规则保存。"""
        ts = result.timestamp or self._now_ts()
        result.timestamp = ts
        safe_tag = "".join(
            ch if (ch.isalnum() or ch in "_-") else "_" for ch in result.query_type
        )
        fname = ts + "_" + safe_tag + ".json"
        path = self.base_dir / fname
        path.write_text(
            json.dumps(result.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return path

    def load(self, path):
        return ResearchResult.from_dict(
            json.loads(path.read_text(encoding="utf-8"))
        )

    def list_files(self):
        return sorted(self.base_dir.glob("*.json"), reverse=True)

    def latest(self, query_type=""):
        """返回最新的调研结果文件。"""
        for p in self.list_files():
            if not query_type or query_type in p.stem:
                return self.load(p)
        return None

    def latest_platform(self, platform):
        """返回指定平台最新的调研结果（文件名含 {platform}_hot）。"""
        marker = platform + "_hot"
        for p in self.list_files():
            if marker in p.stem:
                return self.load(p)
        return None

    def list_platform(self, platform):
        """返回指定平台的所有调研文件（按时间倒序）。"""
        marker = platform + "_hot"
        return [p for p in self.list_files() if marker in p.stem]
