# -*- coding: utf-8 -*-
"""库管理层：事件库 / 主角库 / 配角库 / 地点库 / 时间库 的 JSON 持久化。"""
from .libraries import (
    CharacterLibrary,
    Libraries,
    library_manager,
)
from .research_store import ResearchStore

__all__ = [
    "CharacterLibrary",
    "Libraries",
    "library_manager",
    "ResearchStore",
]
