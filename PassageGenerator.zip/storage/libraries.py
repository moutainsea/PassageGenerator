# -*- coding: utf-8 -*-
"""各库的统一管理：主角形象库、配角形象库、地点库、时间库、事件库。

事件库随小说大纲走，这里管理可复用的角色/地点/时间库文件。
所有库以 JSON 持久化到 output/libraries 目录。

平台隔离：不同小说平台（起点/番茄/飞卢）各自拥有独立的库子目录，
互不混淆。get_libraries(platform) 按平台加载对应库实例。
"""
import json
from pathlib import Path

from config import LIBRARY_DIR, platform_lib_dir, DEFAULT_PLATFORM, NOVEL_PLATFORMS
from models.character import Character, CharacterRole
from models.location import LocationLibrary, Location
from models.timeline import TimelineLibrary, TimePoint


class CharacterLibrary(object):
    """人物形象库：主角与配角分别存储。"""
    def __init__(self, protagonists=None, supporting=None):
        self.protagonists = protagonists if protagonists is not None else {}
        self.supporting = supporting if supporting is not None else {}

    # ---- 主角 ----
    def add_protagonist(self, c):
        if c.role != CharacterRole.PROTAGONIST:
            c.role = CharacterRole.PROTAGONIST
        self.protagonists[c.id] = c

    def get_protagonist(self, cid):
        return self.protagonists.get(cid)

    # ---- 配角 ----
    def add_supporting(self, c):
        if c.role != CharacterRole.SUPPORTING:
            c.role = CharacterRole.SUPPORTING
        self.supporting[c.id] = c

    def get_supporting(self, cid):
        return self.supporting.get(cid)

    def get_any(self, cid):
        return self.protagonists.get(cid) or self.supporting.get(cid)

    def all_characters(self):
        for v in self.protagonists.values():
            yield v
        for v in self.supporting.values():
            yield v

    def to_dict(self):
        return {
            "protagonists": {k: v.to_dict() for k, v in self.protagonists.items()},
            "supporting": {k: v.to_dict() for k, v in self.supporting.items()},
        }

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        prots = {k: Character.from_dict(v) for k, v in data.get("protagonists", {}).items()}
        sups = {k: Character.from_dict(v) for k, v in data.get("supporting", {}).items()}
        return cls(protagonists=prots, supporting=sups)


class Libraries(object):
    """全部库的集合，统一加载/保存。"""
    CHAR_FILE = "character_library.json"
    LOC_FILE = "location_library.json"
    TIME_FILE = "timeline_library.json"

    def __init__(self, characters=None, locations=None, timeline=None, base_dir=None):
        self.characters = characters if characters is not None else CharacterLibrary()
        self.locations = locations if locations is not None else LocationLibrary()
        self.timeline = timeline if timeline is not None else TimelineLibrary()
        # 记忆加载/保存目录，便于 save() 无参时写回原处
        self._base_dir = base_dir

    def save(self, base_dir=None):
        base_dir = base_dir or self._base_dir or LIBRARY_DIR
        base_dir.mkdir(parents=True, exist_ok=True)
        if self._base_dir is None:
            self._base_dir = base_dir
        (base_dir / self.CHAR_FILE).write_text(
            json.dumps(self.characters.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        (base_dir / self.LOC_FILE).write_text(
            json.dumps(self.locations.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        (base_dir / self.TIME_FILE).write_text(
            json.dumps(self.timeline.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    @classmethod
    def load(cls, base_dir=None):
        base_dir = base_dir or LIBRARY_DIR
        libs = cls(base_dir=base_dir)
        cf = base_dir / cls.CHAR_FILE
        if cf.exists():
            libs.characters = CharacterLibrary.from_dict(
                json.loads(cf.read_text(encoding="utf-8"))
            )
        lf = base_dir / cls.LOC_FILE
        if lf.exists():
            libs.locations = LocationLibrary.from_dict(
                json.loads(lf.read_text(encoding="utf-8"))
            )
        tf = base_dir / cls.TIME_FILE
        if tf.exists():
            libs.timeline = TimelineLibrary.from_dict(
                json.loads(tf.read_text(encoding="utf-8"))
            )
        return libs


# 单例：全局共享同一套库（默认平台=起点，向后兼容根目录数据）
library_manager = Libraries.load(platform_lib_dir(DEFAULT_PLATFORM))


# 平台库实例缓存：{platform_code: Libraries}
_platform_libs_cache = {}


def get_libraries(platform=DEFAULT_PLATFORM, reload=False):
    """按平台加载/获取独立库实例。

    每个平台拥有独立的库目录（output/libraries/{platform_code}），
    互不混淆。同一平台多次调用返回缓存实例（除非 reload=True）。
    """
    code = platform if platform in NOVEL_PLATFORMS else DEFAULT_PLATFORM
    if not reload and code in _platform_libs_cache:
        return _platform_libs_cache[code]
    libs = Libraries.load(platform_lib_dir(code))
    _platform_libs_cache[code] = libs
    return libs


def reload_libraries():
    """重新从磁盘加载库（用于外部修改后刷新）。"""
    global library_manager
    library_manager = Libraries.load()
    return library_manager
